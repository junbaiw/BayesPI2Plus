function [out_matrix, AC, TP,FP,TN,FN, Per,direct_binding,indirect_binding]=confusMatrix_2014(f,P_cutoff)
%http://www2.cs.uregina.ca/~dbd/cs831/notes/confusion_matrix/confusion_matrix.html
%function of calculating confusion matrix
%Input file names and P cutoff values
%output: out_matrix countains all confusion matrix of input files,
%	AC is accuracy, TP is true positive rate, FP is false positive rate
%	TN is true negative rate, FN is false negative rate, Per is precision
%
num_of_files=length(f);

%P_cutoff
for i=1:num_of_files
	clear data all_data
%old version
%[id,P,Y,Z,A,Norm_ratio,ratio,count_fwd,count_rev,count_total ]=textread(f{i},'%s%f%f%f%f%f%f%f%f%f','delimiter','\t');
	[data,vars,cases]=tblread(f{i},'\t');
	id=cellstr(cases);
%all_data=[P,Y,Z,A,Norm_ratio,ratio,count_fwd,count_rev,count_total];
	all_data=data;
	dbA=data(:,3);
	P=data(:,4);
	%classify two clustersi, normalized score is better for classifications
	mean_affinity=data(:,2);
%	x=som_normalize(data(:,1),'log')-som_normalize(mean_affinity,'log');
	x=log_normalize(data(:,1))-log_normalize(mean_affinity);
	%x=dbA;
        c=2;
        y0=abs(rand(c,size(x,2))-0.5)*10e-5;
	y0(2,1)=-y0(2,1);
        beta=1.5;
        epc=1*10^(-4);
        N=500;
        isplot=0;
        epochs=100;
	%kmeans is better nGas in classifying two clusters
        %[fuzzy_center, fuzzy_member]=fuzzy_cmean(x,y0,c,epc,beta,N,isplot)
        [fuzzy_center, fuzzy_member]=fuzzy_nGas(x,y0,c,beta,epochs);
        %idx1= find(fuzzy_member(1,:)>fuzzy_member(2,:));
        %idx2=setdiff(1:size(x,1),idx1);
	if fuzzy_center(1)>fuzzy_center(2)
		idx1= find( fuzzy_member(2,:)>fuzzy_member(1,:)); %  & fuzzy_member(2,:)>=0.6 );
        	idx2=setdiff(1:size(x,1),idx1);
		predicted_binding=all_data(idx2,:);
		predicted_nonbinding=all_data(idx1,:);
		
		real_cases=cases(idx2,:);
                notreal_cases=cases(idx1,:);
                out_member1=fuzzy_member(:,idx2);
                out_member2=fuzzy_member(:,idx1);
	else
		idx1= find(fuzzy_member(1,:)>fuzzy_member(2,:)) ; % & fuzzy_member(1,:)>=0.6 );
                idx2=setdiff(1:size(x,1),idx1);
		predicted_binding=all_data(idx2,:);
                predicted_nonbinding=all_data(idx1,:);
		
		real_cases=cases(idx2,:);
                notreal_cases=cases(idx1,:);
                out_member1=fuzzy_member(:,idx2);
                out_member2=fuzzy_member(:,idx1);

	end

	%bellow is condition of expected motif in true target gene for demo data only
	true_pos=predicted_binding(find(predicted_binding(:,9)>0.25 & predicted_binding(:,12) > 0),: );
	false_pos=predicted_binding(find(predicted_binding(:,9)<=0.25 ),:);
	false_neg=predicted_nonbinding(find(predicted_nonbinding(:,9)>0.25 & predicted_nonbinding(:,12)>0),:);
	true_neg=predicted_nonbinding(find(predicted_nonbinding(:,9)<=0.25 ),:); 

	clear a b c d c_matrix
	a=size(true_neg,1);
	b=size(false_pos,1);
	c=size(false_neg,1);
	d=size(true_pos,1);

	% 		predicted predicted 
	%  		neg		pos
	%
	%act neg
	%act pos

	c_matrix(1,1)=a;
	c_matrix(1,2)=b;
	c_matrix(2,1)=c;
	c_matrix(2,2)=d;

	out_matrix{i}=c_matrix;

	%accuracy
	AC(i)=(a+d)/(a+b+c+d)

	%true positive rate
	TP(i)=d/(c+d)

	%false poisitve rate
	FP(i)=b/(a+b)

	%true negative rate
	TN(i)=a/(a+b)

	%)false negative rate
	FN(i)=c/(c+d)

	%precision
	Per(i)=d/(b+d)

	%export data
	varss=cellstr(vars);
	varss{length(varss)+1}='Fuzzy memebr1';
	varss{length(varss)+1}='Fuzzy member2';

	out1=[f{i},'_directBinding']
	out2=[f{i},'_indirectBinding']
	tblwrite([predicted_binding,out_member1'],strvcat(varss),real_cases,out1,'\t');
	tblwrite([predicted_nonbinding,out_member2'],strvcat(varss),notreal_cases,out2,'\t');
	direct_binding{i}=predicted_binding;
	indirect_binding{i}=predicted_nonbinding;

end
%

%plot(FP,TP,'o');
%axis([0 1 0 1])
%xlabel('False Positive Rate (FP)')
%ylabel('True Positive Rate (TP)')
%title('ROC Curve')
%save random_test.mat
