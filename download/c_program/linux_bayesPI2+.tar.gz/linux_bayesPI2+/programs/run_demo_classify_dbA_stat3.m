close all
clear all
f='../run_demos/stat3_demo/in/mm8_STAT3_ESC_Chen.fa_Tags_mlpout_L10_4.mlp_bindingP_0_randomBackground_1000'
P_cutoff=0.09
classify_dbA(f,P_cutoff)



