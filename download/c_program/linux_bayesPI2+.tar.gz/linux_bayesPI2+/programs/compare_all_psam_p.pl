#!/usr/bin/perl -w
use lib "/xanadu/home/junbaiw/local/Perl_Modules";
use strict;

#use Bio::SeqIO;
use Getopt::Long; 
use Cwd;
#This program is used to compare our 
# predicted PSAM with all early known PSAM from SGD ,TRANSFAC or MAcIsacc databases

#read parameters
use vars map {"\$opt_$_"} qw(databaseFile tfName predictedFile cutoff);
GetOptions qw(databaseFile=s tfName=s predictedFile=s cutoff=s);
print "must specify -databaseFile of search database to test." and die unless defined $opt_databaseFile;
print "must specify -tfName of TF name to test." and die unless defined $opt_tfName;
print "must specify -predictedFile of predicted PSAM to test." and die unless defined $opt_predictedFile; 
 
if (not defined $opt_cutoff) {
	$opt_cutoff=0.75;
}

#find out all available files in both databaseFile and predictedFile folds
#read input file names from database  
my $current_path=cwd();
#print "$current_path - $opt_databaseFile\n";

chdir("$opt_databaseFile");
opendir THISDIR, "." or die "not find : $!";
#my $tpwd=cwd();
#print "$tpwd\n";
my @database_file_names= readdir THISDIR;
closedir THISDIR;

#read input file name from predicted Files
chdir("$current_path");
chdir("$opt_predictedFile");
opendir THISDIR, "." or die "not find : $!";
my @predicted_file_names= readdir THISDIR;
closedir THISDIR;

#print "@database_file_names\n";
#print "@predicted_file_names\n";
chdir("$current_path");
#Find TF's known weight matrix in database file
my %need_test_matrixs=();
my @test_matrixs=();
foreach (@database_file_names) {
	$opt_tfName="\U$opt_tfName";
	my $match_name=join "", ('-',$opt_tfName,'_');
	#print "$match_name";
	if (/$match_name/ or ($opt_tfName eq 'ALL' and length($_)>5)) {
	#	print "$_\n";
		push  @test_matrixs, $_;
	}
}
$need_test_matrixs{$opt_tfName}=@test_matrixs;

#read all available matrix
my %tfs_files=();
my %tfs_matrixs=();
my %tfs_title=();
foreach (@test_matrixs) {
        my $input_file=join "\/", ($opt_databaseFile,$_);
        #print "$input_file  \t";
        my ($tf_database_matrix, $tf_database_string, $tf_database_title)=&get_MatrixReduce_PSAM_P($input_file);
	my @temp_database_matrix=@$tf_database_matrix ;
	my $temp_string=join "", @$tf_database_string;
	my $temp_title= $$tf_database_title[0];
	$tfs_matrixs{$temp_string}=[@temp_database_matrix];
	$tfs_files{$temp_string}=$input_file;
	$tfs_title{$temp_string}=$temp_title;
#	print "$temp_string \t $temp_title ";
}
chdir("$current_path");

my @all_input_files=();
my %max_score_for_predicted_matrix=();
if (defined $need_test_matrixs{$opt_tfName} or $opt_tfName eq 'ALL') {
	#for each predicted File try to find its matches in the databaes files
	foreach (@predicted_file_names) {
		my $pred_file=$_;
		my $temp_tfName;
		my $temp_tfName2;
		my $temp_tfName3;
		my $temp_tfName4;
		my $temp_tfName5;
		my $t_=$_;
		$_="\L$_";
#		print "$_\n";
		if (/\.mlp$/) {
			$temp_tfName=join "", ('_',$opt_tfName,'_');
			$temp_tfName2=join "", ('_',$opt_tfName,'.txt');
			$temp_tfName3=join "", ($opt_tfName,'.bsites');
			$temp_tfName4=join "", ($opt_tfName,'_FD05.bsites'); 
			$temp_tfName5=join "", ($opt_tfName,'_');
		} else {
			$temp_tfName=join "", ('-',$opt_tfName,'_');
		}
		#print "$_ , $temp_tfName, $temp_tfName2, $temp_tfName3, $temp_tfName4\n";
		if (/\.mlp$/) {
			my $input_file=join "\/", ($opt_predictedFile,$t_);
			$input_file=~s/ //g;
	#		print "$input_file\n"; 
			my ($tf_matrix, $tf_string,$tf_maximum_feq,$tf_total_maximum)=&get_MatrixReduce_PSAM_F($input_file);
			chdir("$current_path");

                        my @predicted_matrix=@$tf_matrix;
                        my $row=$predicted_matrix[0];
                        my $temp_max=0;
			my @row_max=();
                        # print "$input_file - $#predicted_matrix,  \n";
                       for my $jj (0.. $#{$row}) {
			 	 $temp_max=0;
			#	$predicted_matrix[0][$jj]=($predicted_matrix[0][$jj]+0.31)/($$tf_maximum_feq[$jj]+1);
        		#	$predicted_matrix[1][$jj]=($predicted_matrix[1][$jj]+0.19)/($$tf_maximum_feq[$jj]+1);
			#	$predicted_matrix[2][$jj]=($predicted_matrix[2][$jj]+0.19)/($$tf_maximum_feq[$jj]+1);
			#	$predicted_matrix[3][$jj]=($predicted_matrix[3][$jj]+0.31)/($$tf_maximum_feq[$jj]+1);
				$predicted_matrix[0][$jj]=($predicted_matrix[0][$jj])/($$tf_maximum_feq[$jj]);
                                $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj])/($$tf_maximum_feq[$jj]);
                                $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj])/($$tf_maximum_feq[$jj]);
                                $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj])/($$tf_maximum_feq[$jj]);
                                my $temp_total=$predicted_matrix[0][$jj]+ $predicted_matrix[1][$jj]+ $predicted_matrix[2][$jj]+ $predicted_matrix[3][$jj];
                             #This is for yeast only 
			     #  $predicted_matrix[0][$jj]=($predicted_matrix[0][$jj]) + 0.31/($temp_total+1);
                             #   $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj]) + 0.19/($temp_total+1);
                             #   $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj]) + 0.19/($temp_total+1);
                             #   $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj]) + 0.31/($temp_total+1);

				$predicted_matrix[0][$jj]=($predicted_matrix[0][$jj]) + 0.25/($temp_total+1);
                                $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj]) + 0.25/($temp_total+1);
                                $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj]) + 0.25/($temp_total+1);
                                $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj]) + 0.25/($temp_total+1);

	 		         $temp_total=$predicted_matrix[0][$jj]+ $predicted_matrix[1][$jj]+ $predicted_matrix[2][$jj]+ $predicted_matrix[3][$jj];

				$predicted_matrix[0][$jj]=$predicted_matrix[0][$jj]/$temp_total;
                                $predicted_matrix[1][$jj]=$predicted_matrix[1][$jj]/$temp_total;
                                $predicted_matrix[2][$jj]=$predicted_matrix[2][$jj]/$temp_total;
                                $predicted_matrix[3][$jj]=$predicted_matrix[3][$jj]/$temp_total;

                        #				print "$predicted_matrix[0][$jj],$predicted_matrix[1][$jj], $predicted_matrix[2][$jj], $predicted_matrix[3][$jj]\n";
                        }
			#print "@$tf_maximum_feq\n";
                        #			print "@$tf_string - $$tf_total_maximum\n";

			#compare simility  between predicted matrix with all available matrixs
			foreach (keys %tfs_matrixs) {
				my @matrix=@ {$tfs_matrixs{$_}};
				my $title= $tfs_title{$_};
	#		 	 print "$_, @matrix\n";	
				my ($temp_score, $temp_strand)=&compute_simility_score(\@predicted_matrix,\@matrix); 
			#	 print "$_, $input_file. $pred_file, max= $$temp_score , $$temp_strand\n";	
				my $input_file2=join " vs " , ($tfs_files{$_}, $input_file);
				@{$max_score_for_predicted_matrix{$input_file2}}=($$temp_score, $$temp_strand, $title);	
			}
			push @all_input_files, $input_file;
		 } elsif  ((/_matrixreduce_psam/ and  (/\U$temp_tfName/ or /\L$temp_tfName/)) or (/_Cformat/ and /\U$temp_tfName/) or (/matrix_/ and  /\L$temp_tfName/) ) {
			my $input_file=join "\/", ($opt_predictedFile,$t_);
                        $input_file=~s/ //g;
                      #  print "$input_file\n";
                        my ($tf_matrix, $tf_string,$tf_maximum_feq,$tf_total_maximum)=&get_MatrixReduce_PSAM_F($input_file);
                        chdir("$current_path");

                        my @predicted_matrix=@$tf_matrix;
                        my $row=$predicted_matrix[0];
                        my $temp_max=0;
                        my @row_max=();
			my $len_motif=$#{$row}+1; 	 
                      #  print "$input_file - $#predicted_matrix,  \n";
                       for my $jj (0.. $#{$row}) {
                                 $temp_max=0;
                               # $predicted_matrix[0][$jj]=($predicted_matrix[0][$jj]*$len_motif+0.31)/($$tf_maximum_feq[$jj]*$len_motif+1);
                               # $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj]*$len_motif+0.19)/($$tf_maximum_feq[$jj]*$len_motif+1);
                               # $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj]*$len_motif+0.19)/($$tf_maximum_feq[$jj]*$len_motif+1);
                               # $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj]*$len_motif+0.31)/($$tf_maximum_feq[$jj]*$len_motif+1);
	                        $predicted_matrix[0][$jj]=($predicted_matrix[0][$jj])/($$tf_maximum_feq[$jj]);
                                $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj])/($$tf_maximum_feq[$jj]);
                                $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj])/($$tf_maximum_feq[$jj]);
                                $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj])/($$tf_maximum_feq[$jj]);
                                my $temp_total=$predicted_matrix[0][$jj]+ $predicted_matrix[1][$jj]+ $predicted_matrix[2][$jj]+ $predicted_matrix[3][$jj];
                        #this is for yeast only
			     #   $predicted_matrix[0][$jj]=($predicted_matrix[0][$jj]) + 0.31/($temp_total+1);
                             #   $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj]) + 0.19/($temp_total+1);
                             #   $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj]) + 0.19/($temp_total+1);
                             #   $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj]) + 0.31/($temp_total+1);
                            
   				$predicted_matrix[0][$jj]=($predicted_matrix[0][$jj]) + 0.25/($temp_total+1);
                                $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj]) + 0.25/($temp_total+1);
                                $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj]) + 0.25/($temp_total+1);
                                $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj]) + 0.25/($temp_total+1);

			 	$temp_total=$predicted_matrix[0][$jj]+ $predicted_matrix[1][$jj]+ $predicted_matrix[2][$jj]+ $predicted_matrix[3][$jj];

                                $predicted_matrix[0][$jj]=$predicted_matrix[0][$jj]/$temp_total;
                                $predicted_matrix[1][$jj]=$predicted_matrix[1][$jj]/$temp_total;
                                $predicted_matrix[2][$jj]=$predicted_matrix[2][$jj]/$temp_total;
                                $predicted_matrix[3][$jj]=$predicted_matrix[3][$jj]/$temp_total;


				#print "$predicted_matrix[0][$jj],$predicted_matrix[1][$jj], $predicted_matrix[2][$jj], $predicted_matrix[3][$jj]\n";
                        }
                        #print "@$tf_maximum_feq\n";
                        #print "@$tf_string - $$tf_total_maximum\n";

                        #compare simility  between predicted matrix with all available matrixs
                        foreach (keys %tfs_matrixs) {
                                my @matrix=@ {$tfs_matrixs{$_}};
                                my ($temp_score, $temp_strand)=&compute_simility_score(\@predicted_matrix,\@matrix);
                                #print "$_, $input_file. $pred_file, max= $$temp_score , $$temp_strand\n";      
                                my $input_file2=join " vs " , ($tfs_files{$_}, $input_file);
                                @{$max_score_for_predicted_matrix{$input_file2}}=($$temp_score, $$temp_strand);
                        }
			push @all_input_files, $input_file;
		} 
	}
} else {
	print "Could not find $opt_tfName in the $opt_databaseFile\n";
};
	
#Show results
my $max_score;
my $max_score_strand;	
my $max_score_file;
my $max_score_title;
my $cutoff=$opt_cutoff;

#for each input file find its best match
foreach (@all_input_files) {
	my $temp_input=$_;
	$max_score=0;
	$max_score_strand=();
	$max_score_file=();
	$max_score_title=();

	foreach (keys %max_score_for_predicted_matrix) {
		if (/$temp_input/) {
			if  (@{$max_score_for_predicted_matrix{$_}}[0]>$cutoff) {
				$max_score=@{$max_score_for_predicted_matrix{$_}}[0];
				$max_score_strand=@{$max_score_for_predicted_matrix{$_}}[1];
				$max_score_file=$_;
				$max_score_title=@{$max_score_for_predicted_matrix{$_}}[2];
				print "$max_score_title \t  $opt_tfName\t maximum score\t $max_score_file\t $max_score\t $max_score_strand \n ";	
			}
		} 
	#print "$_ , @{$max_score_for_predicted_matrix{$_}}\n";
	}
#
#	if ($max_score>=$cutoff) {
#		print "$max_score_title \t  $opt_tfName\t maximum score\t $max_score_file\t $max_score\t $max_score_strand \n ";
#	}
}
#print "$opt_tfName\t maximum score\t $max_score_file\t $max_score\t $max_score_strand \n ";


############Below is the subfunctions ###############
sub compute_simility_score{
	my ($t1_matrix, $t2_matrix)=@_;
 	my @predicted_matrix=@$t1_matrix;
	my @known_matrix=@$t2_matrix; 
	my $row1=$predicted_matrix[0];
#	 for my $jj (0.. $#{$row1}) {
#		 print "$predicted_matrix[0][$jj],$predicted_matrix[1][$jj], $predicted_matrix[2][$jj], $predicted_matrix[3][$jj]\n";
#         }
	
	my $row2=$known_matrix[0];
#	for my $jj (0.. $#{$row2}) {
#		print "$known_matrix[0][$jj],$known_matrix[1][$jj], $known_matrix[2][$jj], $known_matrix[3][$jj]\n";
#	}
	
	#print "$#{$row1} , $#{$row2}\n";  	 
	if ($#{$row1}<$#{$row2} ) { #if two WM have different length then use the shorter one to scan the longer one. 
		 #$predicted (row1) shorter than $known matrix (row2)

		#compute score for forward strand move preicted matrix to right side 
                my $len=$#{$row1}+1;    #allignment length
                my $len1=$#{$row2}+1;
                my $initial_pos=0;      #initial position for known matrix
                my $temp_max_score=0;
                my $temp_max_strand=();
		my $minumn_allign_length=int $len; #predicted motif length
	#	print "$len, $len1";
		if ($minumn_allign_length>6 ) {$minumn_allign_length=int $minumn_allign_length*0.95 ;}
                while ($initial_pos<=$len1-$minumn_allign_length) {
                    #    print "1 $initial_pos\n";
			my $temp_score=0;
			my $temp_len=0;
                        for my $jj (0.. $len-1) {
                                if ($jj+$initial_pos<=$#{$row2}) {
                         #              print "$jj - $jj-$initial_pos\n";       
                                        $temp_score=$temp_score+1/(2**0.5)*(($predicted_matrix[0][$jj]-$known_matrix[0][$jj+$initial_pos])**2+
                                                ($predicted_matrix[1][$jj]-$known_matrix[1][$jj+$initial_pos])**2+
                                                ($predicted_matrix[2][$jj]-$known_matrix[2][$jj+$initial_pos])**2+
                                                ($predicted_matrix[3][$jj]-$known_matrix[3][$jj+$initial_pos])**2)**0.5;
						$temp_len++;
                                }
			}
			#$temp_len=$len;	#added june 2009 
		        $temp_score=1-1/$temp_len*$temp_score;
                    #   print "$len, $len1, $temp_score\n";
                        if ($temp_score>$temp_max_score) {
                                $temp_max_score=$temp_score;
                        }
                        $initial_pos++;
                } #end while for move predicted matrix to right side 


		#compute score for forward strand move preicted matrix to left side 
                $initial_pos=0;      #initial position for known matrix
                while ($initial_pos<=$len-$minumn_allign_length) {
                        my $temp_score=0;
                        my $temp_len=0;
                        for my $jj (0.. $len-1) {
                                if ($jj+$initial_pos<=$#{$row1}) {
                                #       print "$jj - $jj-$initial_pos\n"; 
                                        $temp_score=$temp_score+1/(2**0.5)*(($known_matrix[0][$jj]-$predicted_matrix[0][$jj+$initial_pos])**2+
                                                ($known_matrix[1][$jj]-$predicted_matrix[1][$jj+$initial_pos])**2+
                                                ($known_matrix[2][$jj]-$predicted_matrix[2][$jj+$initial_pos])**2+
                                                ($known_matrix[3][$jj]-$predicted_matrix[3][$jj+$initial_pos])**2)**0.5;
                                                $temp_len++;
                                }
                        } 
			# $temp_len=$len; #added june 2009 
                        $temp_score=1-1/$temp_len*$temp_score;
                       # print "$len, $len1, $temp_score\n";
                        if ($temp_score>$temp_max_score) {
                                $temp_max_score=$temp_score;
                        }
                        $initial_pos++;
                } #end while for move predicted matrix to left side 
                $temp_max_strand='F';


		#compute score for reverse strand move predicted matrix to right side 
                $initial_pos=0;      #initial position for known matrix
                my @forward_pos=(0..$len-1);
                my @reverse_pos=();
                for my $i (0..$len-1) {
                        $reverse_pos[$len-1-$i]=$forward_pos[$i];
                }
                while ($initial_pos<=$len1-$minumn_allign_length) {
                        my $temp_score=0;
			my $temp_len=0;
                        for my $jj (0.. $len-1) {
                                if ($jj+$initial_pos<=$#{$row2}) {
                   #                     print "$jj - $jj-$initial_pos\n";
                                        $temp_score=$temp_score+1/(2**0.5)*(($predicted_matrix[3][$reverse_pos[$jj]]-$known_matrix[0][$jj+$initial_pos])**2+
                                                ($predicted_matrix[2][$reverse_pos[$jj]]-$known_matrix[1][$jj+$initial_pos])**2+
                                                ($predicted_matrix[1][$reverse_pos[$jj]]-$known_matrix[2][$jj+$initial_pos])**2+
                                                ($predicted_matrix[0][$reverse_pos[$jj]]-$known_matrix[3][$jj+$initial_pos])**2)**0.5;
						$temp_len++;
                                }
                        }
			# $temp_len=$len; #added june 2009 
                        $temp_score=1-1/$temp_len*$temp_score;
                       # print "$len, $len1, $temp_score\n";
                         if ($temp_score>$temp_max_score) {
                                $temp_max_score=$temp_score;
                                $temp_max_strand='R';
                        }
                        $initial_pos++;
                } #end while   for move predicted matrix to right  

		#compute score for reverse strand move predicted matrix to left side 
                $initial_pos=0;      #initial position for known matrix
                while ($initial_pos<=$len-$minumn_allign_length) {
                        my $temp_score=0;
                        my $temp_len=0;
                        for my $jj (0.. $len-1) {
                                if ($jj+$initial_pos<=$#{$row1}) {
                   #                     print "$jj - $jj-$initial_pos\n";
                                        $temp_score=$temp_score+1/(2**0.5)*(($predicted_matrix[3][$reverse_pos[$jj+$initial_pos]]-$known_matrix[0][$jj])**2+
                                                ($predicted_matrix[2][$reverse_pos[$jj+$initial_pos]]-$known_matrix[1][$jj])**2+
                                                ($predicted_matrix[1][$reverse_pos[$jj+$initial_pos]]-$known_matrix[2][$jj])**2+
                                                ($predicted_matrix[0][$reverse_pos[$jj+$initial_pos]]-$known_matrix[3][$jj])**2)**0.5;
                                                $temp_len++;
                                }
                        }
			 # $temp_len=$len; #added june 2009 
                        $temp_score=1-1/$temp_len*$temp_score;
                       # print "$len, $len1, $temp_score\n";
                         if ($temp_score>$temp_max_score) {
                                $temp_max_score=$temp_score;
                                $temp_max_strand='R';
                        }
                        $initial_pos++;
                } #end while   for move predicted matrix to left  


		return (\$temp_max_score,\$temp_max_strand);
	} else {	#$predicted (row1) longer than $known matrix (row2)
		
		#compute score for forward strand move known matrix to right side
		my $len=$#{$row2}+1;	#allignment length
		my $len1=$#{$row1}+1;
		my $initial_pos=0;	#initial position for known matrix
		my $temp_max_score=0;
		my $temp_max_strand=(); 
		my $minumn_allign_length=int $len; #known motif length
		if ($minumn_allign_length>6 ) {$minumn_allign_length=int $minumn_allign_length*0.95 ;}
		while ($initial_pos<=$len1-$minumn_allign_length) {
		#	print "2 $initial_pos\n";
			my $temp_score=0;
                        my $temp_len=0;
			for my $jj (0.. $len-1) {
				if ($jj+$initial_pos<=$#{$row1}) {
				#	print "$jj - $jj-$initial_pos, $len1\n";	
					$temp_score=$temp_score+1/(2**0.5)*(($known_matrix[0][$jj]-$predicted_matrix[0][$jj+$initial_pos])**2+
						($known_matrix[1][$jj]-$predicted_matrix[1][$jj+$initial_pos])**2+ 
						($known_matrix[2][$jj]-$predicted_matrix[2][$jj+$initial_pos])**2+ 
						($known_matrix[3][$jj]-$predicted_matrix[3][$jj+$initial_pos])**2)**0.5;
                                           $temp_len++;
				} #else { print "$jj - $jj-$initial_pos, $len1\n";}
				
			}
			# print "$len, $len1, $temp_len, $temp_score\n";
			# $temp_len=$len1; #added june 2009 
			$temp_score=1-1/$temp_len*$temp_score;
			if ($temp_score>$temp_max_score) {
				$temp_max_score=$temp_score;
			} 
			$initial_pos++;
		} #end while  move known matrix to right side	
		
		 #compute score for forward strand move known matrix to left side
                $initial_pos=0;      #initial position for known matrix
                if ($minumn_allign_length>6 ) {$minumn_allign_length=int $minumn_allign_length*0.95 ;}
                while ($initial_pos<=$len-$minumn_allign_length) {
                        my $temp_score=0;
                        my $temp_len=0;
                        for my $jj (0.. $len-1) {
                                if ($jj+$initial_pos<=$#{$row2}) {
                        #               print "$jj - $jj-$initial_pos\n";       
                                        $temp_score=$temp_score+1/(2**0.5)*(($predicted_matrix[0][$jj]-$known_matrix[0][$jj+$initial_pos])**2+
                                                ($predicted_matrix[1][$jj]-$known_matrix[1][$jj+$initial_pos])**2+
                                                ($predicted_matrix[2][$jj]-$known_matrix[2][$jj+$initial_pos])**2+
                                                ($predicted_matrix[3][$jj]-$known_matrix[3][$jj+$initial_pos])**2)**0.5;
                                           $temp_len++;
                                }
                        }
		#	 $temp_len=$len1; #added june 2009 
                        $temp_score=1-1/$temp_len*$temp_score;
                #       print "$len, $len1, $temp_score\n";
                        if ($temp_score>$temp_max_score) {
                                $temp_max_score=$temp_score;
                        }
                        $initial_pos++;
                } #end while  move known matrix to right side   
		$temp_max_strand='F';

		
		#compute score for reverse strand move known matrix to right side  
                $initial_pos=0;      #initial position for known matrix
                my @forward_pos=(0..$len-1);
		my @reverse_pos=();
		for my $i (0..$len-1) {
			$reverse_pos[$len-1-$i]=$forward_pos[$i];	
		}
		while ($initial_pos<=$len1-$minumn_allign_length) {
                        my $temp_score=0;
                        my $temp_len=0; 
                        for my $jj (0.. $len-1) {
                                if ($jj+$initial_pos<=$#{$row1}) {
                                      #  print "$jj - $jj-$initial_pos\n";
                                        $temp_score=$temp_score+1/(2**0.5)*(($known_matrix[3][$reverse_pos[$jj]]-$predicted_matrix[0][$jj+$initial_pos])**2+
                                                ($known_matrix[2][$reverse_pos[$jj]]-$predicted_matrix[1][$jj+$initial_pos])**2+
                                                ($known_matrix[1][$reverse_pos[$jj]]-$predicted_matrix[2][$jj+$initial_pos])**2+
                                                ($known_matrix[0][$reverse_pos[$jj]]-$predicted_matrix[3][$jj+$initial_pos])**2)**0.5;
                                        $temp_len++;
                                }       
                        }
			# $temp_len=$len1; #added june 2009 
                        $temp_score=1-1/$temp_len*$temp_score;
                       # print "$len, $len1, $temp_score\n";
                         if ($temp_score>$temp_max_score) {
                                $temp_max_score=$temp_score;
				$temp_max_strand='R';
                        }  
                        $initial_pos++;
                } #end while    move known matrix to right side

		#compute score for reverse strand move known matrix to left side  
                $initial_pos=0;      #initial position for known matrix
                while ($initial_pos<=$len-$minumn_allign_length) {
                        my $temp_score=0;
                        my $temp_len=0;
                        for my $jj (0.. $len-1) {
                                if ($jj+$initial_pos<=$#{$row2}) {
                   #                     print "$jj - $jj-$initial_pos\n";
                                        $temp_score=$temp_score+1/(2**0.5)*(($known_matrix[3][$reverse_pos[$jj+$initial_pos]]-$predicted_matrix[0][$jj])**2+
                                                ($known_matrix[2][$reverse_pos[$jj+$initial_pos]]-$predicted_matrix[1][$jj])**2+
                                                ($known_matrix[1][$reverse_pos[$jj+$initial_pos]]-$predicted_matrix[2][$jj])**2+
                                                ($known_matrix[0][$reverse_pos[$jj+$initial_pos]]-$predicted_matrix[3][$jj])**2)**0.5;
                                        $temp_len++;
                                }
                        }
			# $temp_len=$len1; #added june 2009 
                        $temp_score=1-1/$temp_len*$temp_score;
                       # print "$len, $len1, $temp_score\n";
                         if ($temp_score>$temp_max_score) {
                                $temp_max_score=$temp_score;
                                $temp_max_strand='R';
                        }
                        $initial_pos++;
                } #end while    move known matrix to left side

		return (\$temp_max_score,\$temp_max_strand);	
	}	
}


sub get_MatrixReduce_PSAM_F{
#Get matrixReduce input PSAM in Frequence format
	#print "\t Getting matrtix ...\n";
	my ($matrix_file)=@_;
	#print "\t$matrix_file\n";
	open (DATA,"<$matrix_file") or die "cannot open: $!"; 
	my @matrix_ACGT=();
	my @matrix_string=();
	my $is_record=0;
	my @maximum_feq=();
	my $total_maximum=0; 
	my @matrix_title=(); 
	while (<DATA>) {
		if ($is_record ==1) {
			my @line=split /\t/, $_;
			#print "@line\n";
			my $temp_maximum=0;
			push @matrix_string, $line[0];
			if ($line[1]<exp(-10)) {$line[1]=exp(-10);}
                        if ($line[2]<exp(-10)) {$line[2]=exp(-10);}
                        if ($line[3]<exp(-10)) {$line[3]=exp(-10);}
                        if ($line[4]<exp(-10)) {$line[4]=exp(-10);}

                        if ($line[1]>exp(10)) {$line[1]=exp(10);}
                        if ($line[2]>exp(10)) {$line[2]=exp(10);}
                        if ($line[3]>exp(10)) {$line[3]=exp(10);}
                        if ($line[4]>exp(10)) {$line[4]=exp(10);}


			push @{ $matrix_ACGT[0]}, $line[1];	#add 1 seudo count
			push @{ $matrix_ACGT[1]}, $line[2]; 
			push @{ $matrix_ACGT[2]}, $line[3]; 
			push @{ $matrix_ACGT[3]}, $line[4]; 
			
			#Find out maxium values in each position
			if ($line[1]>$total_maximum) {
				$total_maximum=$line[1];
			}
			  if ($line[2]>$total_maximum) {
                                $total_maximum=$line[2];
                        }
  			if ($line[3]>$total_maximum) {
                                $total_maximum=$line[3];
                        }
  			if ($line[4]>$total_maximum) {
                                $total_maximum=$line[4];
                        }
			#if ($temp_maximum>$total_maximum) {
			#	$total_maximum=$temp_maximum;
			#}

                        #compute total count for each position 
                        $temp_maximum=$line[1]+$line[2]+$line[3]+$line[4];  
			#$temp_maximum=0;
			#for my $j (1..4) {
			#	if ($temp_maximum<$line[$j]) {
			#		$temp_maximum=$line[$j];
			#	}
			#}
			push @maximum_feq, $temp_maximum;	

		}
		if (/^exp/ or /^#/) {
			$is_record=1;
		} else {
			push @matrix_title, $_;
		}
	}
	return (\@matrix_ACGT, \@matrix_string,\@maximum_feq,\$total_maximum, \@matrix_title);
	close DATA;
}


sub get_MatrixReduce_PSAM_P{
#Get matrixReduce input PSAM in Probability format
    #    print "\t Getting matrtix ...\n";
        my ($matrix_file)=@_;
    #    print "\t$matrix_file\n";
        open (DATA,"<$matrix_file") or die "cannot open: $!";
        my @matrix_ACGT=();
        my @matrix_string=();
        my @matrix_title=();
	my $is_record=0;
        while (<DATA>) {
                if ($is_record ==1) {
                        my @line=split /\t/, $_;
                        #print "@line\n"; 
                        push @matrix_string, $line[0];
                        push @{ $matrix_ACGT[0]}, $line[1];   #no seudo count
                        push @{ $matrix_ACGT[1]}, $line[2]; 
                        push @{ $matrix_ACGT[2]}, $line[3]; 
                        push @{ $matrix_ACGT[3]}, $line[4]; 
                }
                if (/^#/) {
                        $is_record=1;
                } else {
			push @matrix_title, $_;
		}
        }
        return (\@matrix_ACGT, \@matrix_string,\@matrix_title);
        close DATA;
}

