#!/usr/bin/perl -w
use lib "/opt/local/lib/perl5/site_perl/5.12.3/";

#use Bio::SeqIO;
use strict;
use Getopt::Long; 
use Cwd;
use DB_File;

use POSIX ":sys_wait_h";
sub REAPER {
    while (waitpid(-1,WNOHANG) >0) {};
    $SIG{CHLD}=\&REAPER;
}


#this program randomly select N subsets of reads from the input data, then run them in N processors in parallel for bayesPI 
#
#
#read parameters
use vars map {"\$opt_$_"} qw(dependence numP strong_expFile numOfStrongReads weak_expFile numOfWeakReads seqFile loops iteration normalization out min_L max_L p_value strand);
GetOptions qw(dependence=s numP=s strong_expFile=s numOfStrongReads=s weak_expFile=s numOfWeakReads=s seqFile=s loops=s iteration=s normalization=s out=s min_L=s max_L=s p_value=s strand=s);
print "must specify -seqFile file for input DNA sequence of all peak calls (both weak and strong calls)  " and die unless defined $opt_seqFile;
print "must specify -strong_expFile file for input Tag counts of strong peak calls " and die unless defined $opt_strong_expFile;
#print "must specify -weak_expFile file for input Tag counts of weak peak calls"  and die unless defined $opt_weak_expFile ;
#print "must specify -iteration for input maximum number of iterations in SCG alogrithm (bayesPI parameter) " and die unless defined $opt_iteration;
#print "must specify -loops file for input maximum number of loops for each motif length (bayesPI parameter) " and die unless defined $opt_loops;
#print "must specify -normalization for input the normalization method for input Tag counts (bayesPI parameter) " and die unless defined $opt_normalization;
print "must specify -out for input the location of output data (bayesPI parameter) " and die unless defined $opt_out;
print "must specify -min_L for input the minimum motif length (bayesPI parameter) " and die unless defined $opt_min_L;
print "must specify -max_L for input the maximum motif length (bayesPI parameter) " and die unless defined $opt_max_L;
#print "must specify -p_value for input the p-value cutoff of motif search (bayesPI paramter) " and die unless defined $opt_p_value;
print "must specify -numP for the number of processors/number of random selection are used in the calculation" and die unless defined $opt_numP;
print "must specify -numOfStrongReads for the number of randomly selceted calls from strong peak calls " and die unless defined $opt_numOfStrongReads;
#print "must specify -numOfWeakReads for the number of randomly selected calls from weak peak calls " and die unless defined $opt_numOfWeakReads;

#Default paramters for bayesPI
if (not defined $opt_dependence) {
	$opt_dependence=0;
}
if (not defined $opt_numOfWeakReads) {
	$opt_numOfWeakReads=0;
}
if (not defined $opt_p_value) {
	$opt_p_value=0.0001;
}
if (not defined $opt_loops) {
	$opt_loops=3;
}
if (not defined $opt_normalization) {
	$opt_normalization=0;
}
if (not defined $opt_iteration) {
	$opt_iteration=500;
}
if (not defined $opt_strand) {
	$opt_strand=0;
}

#maximum to run the program, if exceed it then kill the process
my $max_time=16000;

#read input weak and strong Tag counts of peak calls 
my ($strong_exp, $strong_genes, $strong_head) = &get_exp($opt_strong_expFile);

my %new_weak_exp=();
my @new_weak_genes=();
if (defined $opt_numOfWeakReads and $opt_numOfWeakReads>0 ) {
    my	($weak_exp, $weak_genes, $weak_head) = &get_exp($opt_weak_expFile);

    my $select_weakreads=$opt_numOfWeakReads;
    my $select_strongreads=$opt_numOfStrongReads;
    printf "Randomly select $select_weakreads reads from weak input files\n";
    printf "Randomly select $select_strongreads reads from strong input files\n";

   #exclude strong reads from weak reads
   my $num_in_common=0;
   my $num_in_new=0;
   my $loop=0;
   foreach (@$weak_genes) {
      if (not defined $$strong_exp{$_}) {
          $new_weak_exp{$_}=$$weak_exp{$_};
	  push @new_weak_genes, $_;
          $num_in_new++;
      } else { $num_in_common++;}
          $loop++;
   }
   printf "There are $num_in_common reads overlapping between two files \n";
   printf "Within $loop reads, there are $num_in_new reads in the new weak exp files \n";
} 


#randomly shuffered/select N genes from both weak and strong peak calls then run bayesPI 
#number of processors should equal to the number of run of bayesPI for randomly selected input data
my @pids=();
my $pid=();
my $job_loops;

#loop in processors
for ($job_loops=1;$job_loops<=$opt_numP;$job_loops++) {
	 $pid=fork();
	 if ($pid) {
		 #parent
		 push @pids, $pid;
		 print "processing $pid $job_loops \n";
	} elsif  ($pid==0) {
		#child
		eval {
	 		&random_run_bayesPI($job_loops, $opt_numOfStrongReads, $opt_numOfWeakReads, $opt_seqFile,$opt_strong_expFile,$opt_iteration,$opt_loops,$opt_normalization,
         		$opt_min_L, $opt_max_L, $opt_p_value,$opt_out,\@new_weak_genes, $strong_genes, \%new_weak_exp,$strong_exp,$strong_head,$opt_strand, $opt_dependence); 
		};
		die "\t Done $job_loops \n";
	} else { die "couldn't fork: $!\n";}


#old version
#	die  "could not fork" unless defined(my $pid = fork);
#	unless ($pid) {
#		&random_run_bayesPI($job_loops, $opt_numOfStrongReads, $opt_numOfWeakReads, $opt_seqFile,$opt_strong_expFile,$opt_iteration,$opt_loops,$opt_normalization,
#				    $opt_min_L, $opt_max_L, $opt_p_value,$opt_out,
#				    \@new_weak_genes, $strong_genes, \%new_weak_exp,$strong_exp,$strong_head);	
#		die "\t Done $job_loops ";
#	}
#	push @pids, $pid;
#	print "processing $pid $job_loops \n";
} 

foreach (@pids) {
 	eval {
	 	#set maximum running time for each process!
	 	#
	 	local $SIG{ALRM}=sub {die "TIMEOUT"};
		local $SIG{CHLD}=\&REAPER;
		alarm $max_time;
		my $temp= waitpid($_, 0);
		print "done with pid $temp $_ \n";
		kill 9, $_;
		alarm 0;
	};
	 if ($@ && $@ =~ m/TIMEOUT/) {
		print "job TIMEOUT Kill $_ \n";
		  kill 9, $_;
	}
#old version
#	my $temp= waitpid($_,0);
#	print "Done with pid $temp \n";
}
#end number of processors
print "Done with splitting jobs \n";

#remove tempory files
for ($job_loops=1; $job_loops<=$opt_numP; $job_loops++) {
 	my $temp_name=join "_", ($opt_strong_expFile,$opt_numOfStrongReads, "plus_weak",$opt_numOfWeakReads, $job_loops);
	my @args=qq(rm -f "$temp_name");
	system(@args)==0 or die "system @args failed: $?" ;
}


########################SUBS #########################################
sub random_run_bayesPI {
 my($job_loops, $opt_numOfStrongReads, $opt_numOfWeakReads, $opt_seqFile,$opt_strong_expFile,$opt_iteration,$opt_loops,$opt_normalization,
                                    $opt_min_L, $opt_max_L, $opt_p_value,$opt_out,
                                    $new_weak_genes, $strong_genes, $new_weak_exp,$strong_exp,$strong_head,$opt_strand,$opt_dependence)=@_;
    #random selection in weak and strong peak calls and export data  
    my @weak_keys;
    my @strong_keys=keys %$strong_exp;
    &fisher_yates_shuffle(\@strong_keys);
    if (defined $opt_numOfWeakReads and $opt_numOfWeakReads>0) {
    	@weak_keys=keys %$new_weak_exp;
    	&fisher_yates_shuffle(\@weak_keys);
    }
   
    my @new_weak_keys=();
    my @new_strong_keys=@strong_keys[0..$opt_numOfStrongReads-1];
    my @all_new_keys=(); 
    if (defined $opt_numOfWeakReads and $opt_numOfWeakReads>0) {
	 @new_weak_keys=@weak_keys[0..$opt_numOfWeakReads-1];	
    	 @all_new_keys=(@new_weak_keys,@new_strong_keys) ;
    } else {
	 @all_new_keys=(@new_strong_keys) ;
    }
    #output file name for each randomly selected reads
    my $outExp=join "_", ($opt_strong_expFile,$opt_numOfStrongReads, "plus_weak",$opt_numOfWeakReads, $job_loops);
    &export_tag_counts($outExp, $strong_head, \@all_new_keys,$strong_exp,$new_weak_exp);
    my $opt_numP=$opt_max_L-$opt_min_L+1;
   #run bayesPI on randomly selected peaks 
   #  my @args=("./bayesPI", "-max_loop=$opt_loops","-max_iteration=$opt_iteration","-normalize=$opt_normalization", "-exp=$outExp", "-seq=$opt_seqFile",
   #		"-min_L=$opt_min_L","-max_L=$opt_max_L", "-p_value=$opt_p_value", "-out=$opt_out","\>","$opt_out/log_$job_loops","&");
  # my @args=qq( \(time ./bayesPI -strand="$opt_strand" -max_loop="$opt_loops" -max_iteration="$opt_iteration" -normalize="$opt_normalization" -exp="$outExp" -seq="$opt_seqFile" -min_L="$opt_min_L" -max_L="$opt_max_L" -p_value="$opt_p_value" -out="$opt_out" \) 2> "$opt_out"/log_"$opt_min_L"_"$job_loops" );
 my @args=qq(perl ./programs/run_bayesPI_parallel_by_motifLength.pl -dependence "$opt_dependence" -numP "$opt_numP" -expFile "$outExp" -seqFile "$opt_seqFile" -loops "$opt_loops" -iteration "$opt_iteration" -normalization "$opt_normalization" -min_L "$opt_min_L" -max_L "$opt_max_L" -p_value "$opt_p_value" -strand "$opt_strand" -out "$opt_out");
  system(@args)==0 or die "system  @args failed: $?";
} #end sub

sub export_tag_counts{
        my ($outfile, $column_names_weak, $ids,$strong,$weak)=@_;
        open (DATA, ">$outfile") or die "cannot open: $!";
 	my $new_head= join "\t", ("ID",@$column_names_weak);
	my $new_line=(); 
        print DATA " $new_head\n";
        foreach (@$ids) {
                if (defined $$strong{$_}) {
			$new_line=join "\t", ($_,@{$$strong{$_}});
                        print DATA "$new_line\n";     
                } elsif  (defined $$weak{$_}) { 
			$new_line=join "\t", ($_,@{$$weak{$_}});
                        print DATA "$new_line\n";
                } else { print "not find $_\n";}
        }
        close DATA;
}

sub fisher_yates_shuffle {
    my $array = shift;
    my $i;
    for ($i = @$array; --$i; ) {
        my $j = int rand ($i+1);
        next if $i == $j;
        @$array[$i,$j] = @$array[$j,$i];
    }
}

sub get_seq {                                                                   # Get FASTA data (hash) and Motif dictionary (array)
        print "\tReading sequence data $opt_seqFile ...\n" if defined $opt_seqFile;                 # report progress
        my ($file) = @_;                                                        # Sequence file
        my %fa;                                                                 # Hash for Id->seq
        my $nseqs = 0;                                                          # Record counter
        my $dupes = 0;                                                          # Counter for duplicate IDs
        my $set = Bio::SeqIO->new('-file' => "<$file", '-format' => 'fasta');   # Create new FASTA file object
        while (my $gene = $set->next_seq()){                                    # For each FASTA entry
                $nseqs++;                                                       # Count FASTA file entries
                my $orf = $gene->id();                                          # Get the Gene ID
                $orf=~s/\s//g;           #trim white space
                $orf=~s/'//g;           #trim unregulatory string
                $orf=~s/"//g;
                my $seq = $gene->seq();                                         # Get the sequence
                $seq = "\U$seq";                                                # Force upper case sequence
                if (exists $fa{$orf}){                                          # If this is a duplicate GeneID
                        $dupes++;                                               # Count dupes
                }
                else{
                        $fa{$orf} = $seq;                                       # Build hash of GeneID -> sequence
                }
        }
        print "\t* $nseqs fasta entries (including $dupes duplicates).\n" if defined $opt_seqFile;    # report counts
        return (\%fa);                                                  # Return FASTA data (hash)
}
          

sub get_exp {                                                           # Get hash of orf -> array of logexpr values by experiment
        my ($file) = @_;                                                # File name of expression data file
    	print "\tGetting gene expression data $file ...\n" if defined $file;

	open DATA, "<$file" or die "Could not open $file";              # Open it
        my $head = <DATA>;                                              # Read headers line
        chomp $head;                                                    #
        my @head = split /\t/, $head;                                   # Array of experiment names
        shift @head;                                                    # Remove GeneID column header
        my $nexps = @head;                                              # Number of columns (=experiments)
        my %E;                                                          # Array for list of gene names
        my $nv = 0;                                                     # Number of expression values possible
        my $undefs = 0;                                                 # Init counter for missing expression values
        my @ids;
        my $dupes = 0;
        while (<DATA>){                                                 # For each line in expression file
     #           next unless $_ =~ /\t-?\d*.?\d+/;                       # Skip line if nothing looks like an expression value
                chomp;                                                  #
                $_=~s/\r//g;
		$_=~s/\n//g;
		my @line = split /\t/, $_;                              # GeneID + expression values
                my $orf = shift @line;                                  # Get the orfname and leave the array of log values
                $orf=~s/\s//g;           #trim white space
                $orf=~s/'//g;           #trim unregulatory string
                $orf=~s/"//g;
                for my $exper (0..$#line){                              # Loop across columns
                        $nv++;                                          # Count expression values possible
                        $line[$exper]=~s/\s//g;
			if ($line[$exper] !~ /^-?\d*.?\d+([eE][-+]?\d+)?$/){            # If not a valid (signed) real number
                                $line[$exper] = undef;                  # Flag it as undefined
                                $undefs++;                              # Count the N/A lines
                        }
                }
                if (not defined $E{$orf}){
                        $E{$orf} = \@line ;                             # Create hash entry
                        push @ids, $orf;                                # Add to list of valid orfs
                }
                else {
                        $dupes++;
                }
        }
        my $norfs = @ids;
        close DATA;
        print "\t* $norfs total genes in $nexps experiments (missing $undefs of $nv expression values; $dupes duplicate entries).\n" if defined $file ; # Report        
        return (\%E, \@ids, \@head);                                    # Return hash of genes->expression values
}
 
