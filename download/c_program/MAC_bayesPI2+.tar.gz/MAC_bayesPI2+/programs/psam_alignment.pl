#!/usr/bin/perl -w
use lib "/cluster/home/junbaiw/local/Perl_Modules";
use strict;

#use Bio::SeqIO;
use Getopt::Long; 
use Cwd;
#This program is used to compare our 
# predicted PSAM with all early known PSAM from SGD ,TRANSFAC or MAcIsacc databases

#read parameters
use vars map {"\$opt_$_"} qw(dependence listFile targetFile);
GetOptions qw(listFile=s targetFile=s dependence=s);
print "must specify -listFile of search psam to test." and die unless defined $opt_listFile;
print "must specify -targetFile of target PSAM file to align." and die unless defined $opt_targetFile; 

if (not defined $opt_dependence) {
	$opt_dependence=0;
}


##find out all available psam files from listFile
my @list_files=();
my %dep_files=();
my @dep_row_ids=();
for my $i (0.. 50) { 
	$dep_row_ids[$i]=join ",", ($i+1, $i+2);
#	print "$dep_row_ids[$i]\n";
}

open LIST, "<$opt_listFile" or die "cannot open: $!";
while (<LIST>) {
	if (/ALL/) {
		my @line=split /\svs\s/, $_;
		my $temp_file=$line[1];
		my @line2=split /\s/, $temp_file;
		$temp_file=$line2[0];
		push @list_files, $temp_file;
		print "psam file in --> $temp_file \n";

		if ($opt_dependence==1) {
		#find interaction files
			my $temp_dep=$temp_file;
			$temp_dep=~s/_mlpout_/_Wij_/;
			$temp_dep=~s/\.mlp$/\.intect/;
			$dep_files{$temp_file}=$temp_dep;
			print "dependence matrix \t\t $temp_dep \n";	
		}
	}
}
close LIST;
print "Targt file in --> $opt_targetFile \n";
#read target file
my ($tf_target_matrix, $tf_target_string)=&get_MatrixReduce_PSAM_P($opt_targetFile);


#do alignment for each listed files
my @mean_matrix=();
my @mean_dep_matrix=();
my @sqr_of_mean_matrix=();
my $row=@$tf_target_matrix[0];
my $len=$#{$row}+1;
#assign initial value to mean_matrix
for my $jj (0.. $len+30) {
     $mean_matrix[0][$jj]=0;
     $mean_matrix[1][$jj]=0;
     $mean_matrix[2][$jj]=0;
     $mean_matrix[3][$jj]=0;
     $sqr_of_mean_matrix[0][$jj]=0; 
     $sqr_of_mean_matrix[1][$jj]=0;
     $sqr_of_mean_matrix[2][$jj]=0;
     $sqr_of_mean_matrix[3][$jj]=0;
    for my $kk (0.. 16) {
	$mean_dep_matrix[$kk][$jj]=0;
   }
}
my $total_psam=$#list_files+1;
my $len_of_psam=10000;
my $num_of_head=0;
my $dep_head=();
foreach (@list_files)  {
	#load matrix find alignment to the target matrix
	my $in_file=$_;
	my ($tf_matrix, $tf_string,$tf_maximum_feq,$tf_total_maximum)=&get_MatrixReduce_PSAM_F($in_file);
	my $dep_in_file=();
	my $dep_matrice=();
	my $dep_id=();
	$dep_head=();
	if ($opt_dependence==1) {
		$dep_in_file=$dep_files{$in_file};
		#read dependence matrix
		($dep_matrice, $dep_id, $dep_head) = &get_exp($dep_in_file);
	#	print "$dep_row_ids[1], $$dep_id[0], @$dep_head\n";
		$num_of_head=@$dep_head;	
	}
	
	#inital matrix
	my @predicted_matrix=();
	@predicted_matrix=&frequency_to_probability($tf_matrix,$tf_maximum_feq);         
	my ($temp_score, $temp_strand, $temp_pos, $temp_direction)=&compute_simility_score_with_aligned_position(\@predicted_matrix,$tf_target_matrix);
  	print "$in_file,  max= $$temp_score , $$temp_strand, $$temp_pos, $$temp_direction \n";

  	#row1 for predicted matrice 
        my $row1=$predicted_matrix[0];
	my $len=$#{$row1}+1;
	if ($len<$len_of_psam) {
		$len_of_psam=$len;
#		print "len $len_of_psam \n";
	}
        my @forward_pos=(0..$len-1);
        my @reverse_pos=();
        for my $i (0..$len-1) {
           $reverse_pos[$len-1-$i]=$forward_pos[$i];
        }

	my $initial_pos=();
	if ($$temp_strand eq 'F' and $$temp_direction eq 'right') {
		$initial_pos=-$$temp_pos;
	} elsif ($$temp_strand eq 'F' and $$temp_direction eq 'left') {
		$initial_pos=$$temp_pos;
	} elsif ($$temp_strand eq 'R' and $$temp_direction eq 'left') {
                $initial_pos=$$temp_pos;
	} elsif ($$temp_strand eq 'R' and $$temp_direction eq 'right') {
                $initial_pos=-$$temp_pos;
	}
	
	#reload original matrix for calculate mean
	($tf_matrix, $tf_string,$tf_maximum_feq,$tf_total_maximum)=&get_MatrixReduce_PSAM_F($in_file);
	my @predicted_matrixF=@$tf_matrix;

    if ($$temp_score>0.7 ) {
	#forward strand
	if ($$temp_strand eq 'F') {
		for my $jj (0.. $len-1) {
			if ($jj+$initial_pos<$len and $jj+$initial_pos>=0) {
#log scale better than real scale for mean
# 				$mean_matrix[0][$jj]=$mean_matrix[0][$jj]+($predicted_matrixF[0][$jj+$initial_pos]); 
#                                $mean_matrix[1][$jj]=$mean_matrix[1][$jj]+($predicted_matrixF[1][$jj+$initial_pos]);
#                                $mean_matrix[2][$jj]=$mean_matrix[2][$jj]+($predicted_matrixF[2][$jj+$initial_pos]);
#                                $mean_matrix[3][$jj]=$mean_matrix[3][$jj]+($predicted_matrixF[3][$jj+$initial_pos]);
#                                     
#                                $sqr_of_mean_matrix[0][$jj]= $sqr_of_mean_matrix[0][$jj]+($predicted_matrixF[0][$jj+$initial_pos])*($predicted_matrixF[0][$jj+$initial_pos]);
#                                $sqr_of_mean_matrix[1][$jj]= $sqr_of_mean_matrix[1][$jj]+($predicted_matrixF[1][$jj+$initial_pos])*($predicted_matrixF[1][$jj+$initial_pos]);
#                                $sqr_of_mean_matrix[2][$jj]= $sqr_of_mean_matrix[2][$jj]+($predicted_matrixF[2][$jj+$initial_pos])*($predicted_matrixF[2][$jj+$initial_pos]);
#                                $sqr_of_mean_matrix[3][$jj]= $sqr_of_mean_matrix[3][$jj]+($predicted_matrixF[3][$jj+$initial_pos])*($predicted_matrixF[3][$jj+$initial_pos]);

				$mean_matrix[0][$jj]=$mean_matrix[0][$jj]-log($predicted_matrixF[0][$jj+$initial_pos]);	
   				$mean_matrix[1][$jj]=$mean_matrix[1][$jj]-log($predicted_matrixF[1][$jj+$initial_pos]);
   				$mean_matrix[2][$jj]=$mean_matrix[2][$jj]-log($predicted_matrixF[2][$jj+$initial_pos]);
   				$mean_matrix[3][$jj]=$mean_matrix[3][$jj]-log($predicted_matrixF[3][$jj+$initial_pos]);
	
				$sqr_of_mean_matrix[0][$jj]= $sqr_of_mean_matrix[0][$jj]+log($predicted_matrixF[0][$jj+$initial_pos])*log($predicted_matrixF[0][$jj+$initial_pos]);
				$sqr_of_mean_matrix[1][$jj]= $sqr_of_mean_matrix[1][$jj]+log($predicted_matrixF[1][$jj+$initial_pos])*log($predicted_matrixF[1][$jj+$initial_pos]);
				$sqr_of_mean_matrix[2][$jj]= $sqr_of_mean_matrix[2][$jj]+log($predicted_matrixF[2][$jj+$initial_pos])*log($predicted_matrixF[2][$jj+$initial_pos]);
				$sqr_of_mean_matrix[3][$jj]= $sqr_of_mean_matrix[3][$jj]+log($predicted_matrixF[3][$jj+$initial_pos])*log($predicted_matrixF[3][$jj+$initial_pos]);
	
				
				if ($opt_dependence==1) {
					if (defined $$dep_matrice{$dep_row_ids[$jj+$initial_pos]} ) {
						my @temp_dep_matrice= @{$$dep_matrice{$dep_row_ids[$jj+$initial_pos]}};
						for my $kkk (0.. 15) {
						#	print "$jj, $kkk \n";
							$mean_dep_matrix[$kkk][$jj]=$mean_dep_matrix[$kkk][$jj]+$temp_dep_matrice[$kkk];
						}
					}
				}
			}
		}
	} elsif ($$temp_strand eq 'R') {
	 	for my $jj (0.. $len-1) {
             		if ($jj+$initial_pos<$len and $jj+$initial_pos>=0) {
#REAL SCALE
#			       $mean_matrix[0][$jj]=$mean_matrix[0][$jj]+($predicted_matrixF[3][$reverse_pos[$jj+$initial_pos]]);
#                               $mean_matrix[1][$jj]=$mean_matrix[1][$jj]+($predicted_matrixF[2][$reverse_pos[$jj+$initial_pos]]);
#                               $mean_matrix[2][$jj]=$mean_matrix[2][$jj]+($predicted_matrixF[1][$reverse_pos[$jj+$initial_pos]]);
#                               $mean_matrix[3][$jj]=$mean_matrix[3][$jj]+($predicted_matrixF[0][$reverse_pos[$jj+$initial_pos]]);
                       
#			       $sqr_of_mean_matrix[0][$jj]=$sqr_of_mean_matrix[0][$jj]+($predicted_matrixF[3][$reverse_pos[$jj+$initial_pos]])*($predicted_matrixF[3][$reverse_pos[$jj+$initial_pos]]);
#                               $sqr_of_mean_matrix[1][$jj]=$sqr_of_mean_matrix[1][$jj]+($predicted_matrixF[2][$reverse_pos[$jj+$initial_pos]])*($predicted_matrixF[2][$reverse_pos[$jj+$initial_pos]]);
#                               $sqr_of_mean_matrix[2][$jj]=$sqr_of_mean_matrix[2][$jj]+($predicted_matrixF[1][$reverse_pos[$jj+$initial_pos]])*($predicted_matrixF[1][$reverse_pos[$jj+$initial_pos]]);
#                               $sqr_of_mean_matrix[3][$jj]=$sqr_of_mean_matrix[3][$jj]+($predicted_matrixF[0][$reverse_pos[$jj+$initial_pos]])*($predicted_matrixF[0][$reverse_pos[$jj+$initial_pos]]);

#LOG SCALE
			#	print "$jj, $jj+$initial_pos , $reverse_pos[$jj+$initial_pos] , $predicted_matrixF[3][$reverse_pos[$jj+$initial_pos]]\n"; 
				$mean_matrix[0][$jj]=$mean_matrix[0][$jj]-log($predicted_matrixF[3][$reverse_pos[$jj+$initial_pos]]);
				$mean_matrix[1][$jj]=$mean_matrix[1][$jj]-log($predicted_matrixF[2][$reverse_pos[$jj+$initial_pos]]);
				$mean_matrix[2][$jj]=$mean_matrix[2][$jj]-log($predicted_matrixF[1][$reverse_pos[$jj+$initial_pos]]);
				$mean_matrix[3][$jj]=$mean_matrix[3][$jj]-log($predicted_matrixF[0][$reverse_pos[$jj+$initial_pos]]);
#
			        $sqr_of_mean_matrix[0][$jj]=$sqr_of_mean_matrix[0][$jj]+log($predicted_matrixF[3][$reverse_pos[$jj+$initial_pos]])*log($predicted_matrixF[3][$reverse_pos[$jj+$initial_pos]]);
                                $sqr_of_mean_matrix[1][$jj]=$sqr_of_mean_matrix[1][$jj]+log($predicted_matrixF[2][$reverse_pos[$jj+$initial_pos]])*log($predicted_matrixF[2][$reverse_pos[$jj+$initial_pos]]);
                                $sqr_of_mean_matrix[2][$jj]=$sqr_of_mean_matrix[2][$jj]+log($predicted_matrixF[1][$reverse_pos[$jj+$initial_pos]])*log($predicted_matrixF[1][$reverse_pos[$jj+$initial_pos]]);
                                $sqr_of_mean_matrix[3][$jj]=$sqr_of_mean_matrix[3][$jj]+log($predicted_matrixF[0][$reverse_pos[$jj+$initial_pos]])*log($predicted_matrixF[0][$reverse_pos[$jj+$initial_pos]]);


				if ($opt_dependence==1) {
                                    if (defined $$dep_matrice{$dep_row_ids[$reverse_pos[$jj+$initial_pos]]} ) {
                                        my @temp_dep_matrice= @{$$dep_matrice{$dep_row_ids[$reverse_pos[$jj+$initial_pos]]}};
                                        my $temp_idx=15; 
					for my $kkk (0.. 15) {
                                                $mean_dep_matrix[$kkk][$jj]=$mean_dep_matrix[$kkk][$jj]+$temp_dep_matrice[$temp_idx];
						$temp_idx--;
                                         }
                                     }
                                }
             		}
         	}
	}
    } else { 
	print "Remove $in_file \n";
	$total_psam=$total_psam-1;	
    }
}

#computer mean of matrix
my @out_motif=();
#print "$len_of_psam \n";
for my $jj (0.. $len_of_psam-1) {
#REAL scale
# 	 $mean_matrix[0][$jj]=($mean_matrix[0][$jj]/($total_psam));
#	 $mean_matrix[1][$jj]=($mean_matrix[1][$jj]/($total_psam));
#         $mean_matrix[2][$jj]=($mean_matrix[2][$jj]/($total_psam));
#         $mean_matrix[3][$jj]=($mean_matrix[3][$jj]/($total_psam));

#log scale
	  $mean_matrix[0][$jj]=exp(-$mean_matrix[0][$jj]/($total_psam));
	  $mean_matrix[1][$jj]=exp(-$mean_matrix[1][$jj]/($total_psam));
 	  $mean_matrix[2][$jj]=exp(-$mean_matrix[2][$jj]/($total_psam));
 	  $mean_matrix[3][$jj]=exp(-$mean_matrix[3][$jj]/($total_psam));

	if ($opt_dependence==1) {
	 	for my $kk (0.. 15) {
			$mean_dep_matrix[$kk][$jj]=$mean_dep_matrix[$kk][$jj]/$total_psam;
		}
	}
	 my $temp_max=0;
	 my $temp_pos=();
	 for my $i (0..3) {
		if ($mean_matrix[$i][$jj]>$temp_max) {
			$temp_max=$mean_matrix[$i][$jj];
			$temp_pos=$i;
		}
	 }
	 if ($temp_pos==0) { push @out_motif, 'a' ;}
 	 elsif ($temp_pos==1) { push @out_motif, 'c' ;}
	 elsif ($temp_pos==2) { push @out_motif, 'g' ;}
	 elsif ($temp_pos==3) { push @out_motif, 't' ;}
	 #print "$out_motif[$jj], $mean_matrix[0][$jj] \t $mean_matrix[1][$jj] \t $mean_matrix[2][$jj] \t $mean_matrix[3][$jj] \n";
}

#compute standard deviation of matrix
my @std_matrix=();
for my $jj (0.. $len_of_psam-1) {
#REAL scale
#	  $std_matrix[0][$jj]=sqrt($sqr_of_mean_matrix[0][$jj]/$total_psam-($mean_matrix[0][$jj])*($mean_matrix[0][$jj]));
#          $std_matrix[1][$jj]=sqrt($sqr_of_mean_matrix[1][$jj]/$total_psam-($mean_matrix[1][$jj])*($mean_matrix[1][$jj]));
#          $std_matrix[2][$jj]=sqrt($sqr_of_mean_matrix[2][$jj]/$total_psam-($mean_matrix[2][$jj])*($mean_matrix[2][$jj]));
#          $std_matrix[3][$jj]=sqrt($sqr_of_mean_matrix[3][$jj]/$total_psam-($mean_matrix[3][$jj])*($mean_matrix[3][$jj]));

#Log SCALe
          $std_matrix[0][$jj]=sqrt($sqr_of_mean_matrix[0][$jj]/$total_psam-log($mean_matrix[0][$jj])*log($mean_matrix[0][$jj]));
          $std_matrix[1][$jj]=sqrt($sqr_of_mean_matrix[1][$jj]/$total_psam-log($mean_matrix[1][$jj])*log($mean_matrix[1][$jj]));
          $std_matrix[2][$jj]=sqrt($sqr_of_mean_matrix[2][$jj]/$total_psam-log($mean_matrix[2][$jj])*log($mean_matrix[2][$jj]));
          $std_matrix[3][$jj]=sqrt($sqr_of_mean_matrix[3][$jj]/$total_psam-log($mean_matrix[3][$jj])*log($mean_matrix[3][$jj]));
}

#export mean psam
my $out_file=join "_", ($opt_listFile,"meanPSAM.mlp");
my $temp_motif=join "", @out_motif;
open DATA, ">$out_file " or die "cannot open: $!";
print DATA "$temp_motif \t # \t $opt_listFile\n";
print DATA "0 \t # \t P-value\n";
print DATA "1 \t # \t \n";
print DATA "0 \t 1 \t 0 \t # b1, w2, b2, T-value, R2, alpha-w1, alpha-b1, alpha-w2, alpha-b2, beta \n";
print DATA "# a c g t # \t mean exp(-E)\n";
for my $i (0..$#out_motif) {
	print DATA "$out_motif[$i]\t$mean_matrix[0][$i]\t$mean_matrix[1][$i]\t$mean_matrix[2][$i]\t$mean_matrix[3][$i]\n";
}
close DATA;

#export std of mean psam
$out_file=join "_", ($opt_listFile,"stdOf_meanPSAM.mlp");
$temp_motif=join "", @out_motif;
open DATA, ">$out_file " or die "cannot open: $!";
print DATA "$temp_motif \t # \t $opt_listFile\n";
print DATA "0 \t # \t P-value\n";
print DATA "1 \t # \t \n";
print DATA "0 \t 1\t 0  # b1, w2, b2, T-value, R2, alpha-w1, alpha-b1, alpha-w2, alpha-b2, beta \n";
print DATA "# a c g t # \t std -log(E)\n";
for my $i (0..$#out_motif) {
        print DATA "$out_motif[$i]\t$std_matrix[0][$i]\t$std_matrix[1][$i]\t$std_matrix[2][$i]\t$std_matrix[3][$i]\n";
}
close DATA;

#export mean of depenence matrice
if ($opt_dependence==1) {
	$out_file=join "_", ($opt_listFile, "meanDependence.intect");
	open DATA, ">$out_file " or die "cannot open: $!";
	my $heads=join "\t", (@$dep_head);
	$heads=~s/ //g;
	print DATA "$heads\n";
	for my $i (0.. $#out_motif) {
		print DATA "$dep_row_ids[$i]\t";
		for my $k (0.. 14) {
			my $temp=$mean_dep_matrix[$k][$i];
			print DATA "$temp\t"; 
		}
		print DATA "$mean_dep_matrix[15][$i]\n";
	}
	close DATA;
}

############Below is the subfunctions ###############
sub compute_simility_score_with_aligned_position{
	my ($t1_matrix, $t2_matrix)=@_;
 	my @predicted_matrix=@$t1_matrix;
	my @known_matrix=@$t2_matrix;
	#row1 for predicted matrice 
	my $row1=$predicted_matrix[0];
#	 for my $jj (0.. $#{$row1}) {
#		 print "$predicted_matrix[0][$jj],$predicted_matrix[1][$jj], $predicted_matrix[2][$jj], $predicted_matrix[3][$jj]\n";
#         }
	
	#row 2 for target matrice
	my $row2=$known_matrix[0];
#	for my $jj (0.. $#{$row2}) {
#		print "$known_matrix[0][$jj],$known_matrix[1][$jj], $known_matrix[2][$jj], $known_matrix[3][$jj]\n";
#	}

	#here we fix target matrice then use predicted matrice to scane it regardless the length differenece between them
	#compute score for forward strand move preicted matrix to right side 
	#forward strand and move right, the initial position is always 0,
        my $len=$#{$row1}+1;    #allignment predicted motif length
        my $len1=$#{$row2}+1;   #targeted motif length 
        my $initial_pos=0;      #initial position for known matrix
        my $temp_max_score=0;
        my $temp_max_strand=();
        my $temp_max_pos=();
	my $temp_max_direction=();
	my $minumn_allign_length=int $len1; #use targeted motif length

	#fill 0 at the end of matrix
#	if ($len>$len1) {
	#predicted length>targted length
#		print "$len $len1 \n";
#		for my $k ($len1..$len-1) {
#			$known_matrix[0][$k]=0;
#			$known_matrix[1][$k]=0;
#			$known_matrix[2][$k]=0;
# 			$known_matrix[3][$k]=0;
#		}
#	} elsif ($len1> $len) {
#	if  ($len1> $len) {
	#predicted length < targeted length
#		print "$len1 $len \n";
#		  for my $k ($len.. $len1-1) {
#                        $predicted_matrix[0][$k]=0;
#                        $predicted_matrix[1][$k]=0;
#                        $predicted_matrix[2][$k]=0;
#                        $predicted_matrix[3][$k]=0;
#                }
#	}



	if ($minumn_allign_length>6 ) {$minumn_allign_length=int $minumn_allign_length*0.9 ;}
        while ($initial_pos<=$len1-$minumn_allign_length) {
              #    print "1 $initial_pos\n";
		my $temp_score=0;
		my $temp_len=0;
                for my $jj (0.. $len1-1) {
                        if ($jj+$initial_pos<=$#{$row2} and $jj+$initial_pos<=$#{$row1}) {
                            #  print "$jj ,- $jj+$initial_pos, $predicted_matrix[0][$jj], $known_matrix[0][$jj+$initial_pos]\n";       
                               $temp_score=$temp_score+1/(2**0.5)*(($predicted_matrix[0][$jj]-$known_matrix[0][$jj+$initial_pos])**2+
                               ($predicted_matrix[1][$jj]-$known_matrix[1][$jj+$initial_pos])**2+
                               ($predicted_matrix[2][$jj]-$known_matrix[2][$jj+$initial_pos])**2+
                               ($predicted_matrix[3][$jj]-$known_matrix[3][$jj+$initial_pos])**2)**0.5;
				$temp_len++;
                        }
		}
		#$temp_len=$len;	#added june 2009 
	        $temp_score=1-1/$temp_len*$temp_score;
               #   print "$len, $len1, $temp_score\n";
               if ($temp_score>$temp_max_score) {
                  $temp_max_score=$temp_score;
		 $temp_max_pos=$initial_pos;
		 $temp_max_direction='right';
               }
              $initial_pos++;
       } #end while for move predicted matrix to right side 


       #compute score for forward strand move preicted matrix to left side 
       #forward strand and move left, the inital position is temp_max_pos
       $initial_pos=0;      #initial position for known matrix
       while ($initial_pos<=$len-$minumn_allign_length) {
             my $temp_score=0;
             my $temp_len=0;
             for my $jj (0.. $len1-1) {
                 if ($jj+$initial_pos<=$#{$row1} ) {
                        # print "$jj - $jj-$initial_pos\n"; 
                       $temp_score=$temp_score+1/(2**0.5)*(($known_matrix[0][$jj]-$predicted_matrix[0][$jj+$initial_pos])**2+
                       ($known_matrix[1][$jj]-$predicted_matrix[1][$jj+$initial_pos])**2+
                       ($known_matrix[2][$jj]-$predicted_matrix[2][$jj+$initial_pos])**2+
                       ($known_matrix[3][$jj]-$predicted_matrix[3][$jj+$initial_pos])**2)**0.5;
                       $temp_len++;
                 }
              } 
	# $temp_len=$len; #added june 2009 
             $temp_score=1-1/$temp_len*$temp_score;
             # print "$len, $len1, $temp_score\n";
            if ($temp_score>$temp_max_score) {
                 $temp_max_score=$temp_score;
		$temp_max_pos=$initial_pos;
		$temp_max_direction='left';
            }
           $initial_pos++;
    } #end while for move predicted matrix to left side 
     $temp_max_strand='F';


    #compute score for reverse strand move predicted matrix to right side
    #reverse strand and move right, the initial position is always 0. 
    $initial_pos=0;      #initial position for known matrix
    my @forward_pos=(0..$len-1);
    my @reverse_pos=();
    for my $i (0..$len-1) {
           $reverse_pos[$len-1-$i]=$forward_pos[$i];
    }
    while ($initial_pos<=$len1-$minumn_allign_length) {
          my $temp_score=0;
	  my $temp_len=0;
          for my $jj (0.. $len-1) {
               if ($jj+$initial_pos<=$#{$row2}) {
          #                     print "$jj - $jj-$initial_pos\n";
                   $temp_score=$temp_score+1/(2**0.5)*(($predicted_matrix[3][$reverse_pos[$jj]]-$known_matrix[0][$jj+$initial_pos])**2+
                   ($predicted_matrix[2][$reverse_pos[$jj]]-$known_matrix[1][$jj+$initial_pos])**2+
                   ($predicted_matrix[1][$reverse_pos[$jj]]-$known_matrix[2][$jj+$initial_pos])**2+
                   ($predicted_matrix[0][$reverse_pos[$jj]]-$known_matrix[3][$jj+$initial_pos])**2)**0.5;
		   $temp_len++;
               }
          }
	# $temp_len=$len; #added june 2009 
        $temp_score=1-1/$temp_len*$temp_score;
        # print "$len, $len1, $temp_score\n";
       if ($temp_score>$temp_max_score) {
              $temp_max_score=$temp_score;
	      $temp_max_pos=$initial_pos;
              $temp_max_strand='R';
	      $temp_max_direction='right';
        }
       $initial_pos++;
   } #end while   for move predicted matrix to right  

   #compute score for reverse strand move predicted matrix to left side 
   #reverse strand and move left, the initial position is temp_max_pos
   $initial_pos=0;      #initial position for known matrix
   while ($initial_pos<=$len-$minumn_allign_length) {
         my $temp_score=0;
         my $temp_len=0;
         for my $jj (0.. $len-1) {
             if ($jj+$initial_pos<=$#{$row1} and $jj<$len1) {
   #                     print "$jj - $jj-$initial_pos\n";
                    $temp_score=$temp_score+1/(2**0.5)*(($predicted_matrix[3][$reverse_pos[$jj+$initial_pos]]-$known_matrix[0][$jj])**2+
                    ($predicted_matrix[2][$reverse_pos[$jj+$initial_pos]]-$known_matrix[1][$jj])**2+
                    ($predicted_matrix[1][$reverse_pos[$jj+$initial_pos]]-$known_matrix[2][$jj])**2+
                    ($predicted_matrix[0][$reverse_pos[$jj+$initial_pos]]-$known_matrix[3][$jj])**2)**0.5;
                    $temp_len++;
              }
           }
	 # $temp_len=$len; #added june 2009 
          $temp_score=1-1/$temp_len*$temp_score;
         # print "$len, $len1, $temp_score\n";
        if ($temp_score>$temp_max_score) {
                 $temp_max_score=$temp_score;
		 $temp_max_pos=$initial_pos;
                 $temp_max_strand='R';
		$temp_max_direction='left';
        }
        $initial_pos++;
   } #end while   for move predicted matrix to left  
   return (\$temp_max_score,\$temp_max_strand,\$temp_max_pos, \$temp_max_direction);
}


sub get_MatrixReduce_PSAM_F{
#Get matrixReduce input PSAM in Frequence format
	#print "\t Getting matrtix ...\n";
	my ($matrix_file)=@_;
	#print "\t$matrix_file\n";
	open (DATA,"<$matrix_file") or die "cannot open: $!"; 
	my @matrix_ACGT=();

	#initial matrix
	#  for my $kk (0.. 50)  {
        #        $matrix_ACGT[0][$kk]=0;
        #        $matrix_ACGT[1][$kk]=0;
        #        $matrix_ACGT[2][$kk]=0;
        #        $matrix_ACGT[3][$kk]=0;
        #}

	my @matrix_string=();
	my $is_record=0;
	my @maximum_feq=();
	my $total_maximum=0; 
	my @matrix_title=(); 
	while (<DATA>) {
		if ($is_record ==1) {
			my @line=split /\t/, $_;
			#print "@line\n";
			my $temp_maximum=0;
			push @matrix_string, $line[0];
			if ($line[1]<exp(-10)) {$line[1]=exp(-10);}
                        if ($line[2]<exp(-10)) {$line[2]=exp(-10);}
                        if ($line[3]<exp(-10)) {$line[3]=exp(-10);}
                        if ($line[4]<exp(-10)) {$line[4]=exp(-10);}

                        if ($line[1]>exp(10)) {$line[1]=exp(10);}
                        if ($line[2]>exp(10)) {$line[2]=exp(10);}
                        if ($line[3]>exp(10)) {$line[3]=exp(10);}
                        if ($line[4]>exp(10)) {$line[4]=exp(10);}


			push @{ $matrix_ACGT[0]}, $line[1];	#add 1 seudo count
			push @{ $matrix_ACGT[1]}, $line[2]; 
			push @{ $matrix_ACGT[2]}, $line[3]; 
			push @{ $matrix_ACGT[3]}, $line[4]; 
			
			#Find out maxium values in each position
			if ($line[1]>$total_maximum) {
				$total_maximum=$line[1];
			}
			  if ($line[2]>$total_maximum) {
                                $total_maximum=$line[2];
                        }
  			if ($line[3]>$total_maximum) {
                                $total_maximum=$line[3];
                        }
  			if ($line[4]>$total_maximum) {
                                $total_maximum=$line[4];
                        }
			#if ($temp_maximum>$total_maximum) {
			#	$total_maximum=$temp_maximum;
			#}

                        #compute total count for each position 
                        $temp_maximum=$line[1]+$line[2]+$line[3]+$line[4];  
			#$temp_maximum=0;
			#for my $j (1..4) {
			#	if ($temp_maximum<$line[$j]) {
			#		$temp_maximum=$line[$j];
			#	}
			#}
			push @maximum_feq, $temp_maximum;	

		}
		if (/^exp/ or /^#/) {
			$is_record=1;
		} else {
			push @matrix_title, $_;
		}
	}
	return (\@matrix_ACGT, \@matrix_string,\@maximum_feq,\$total_maximum, \@matrix_title);
	close DATA;
}


sub get_MatrixReduce_PSAM_P{
#Get matrixReduce input PSAM in Probability format
    #    print "\t Getting matrtix ...\n";
        my ($matrix_file)=@_;
        print "\t$matrix_file\n";
        open (DATA,"<$matrix_file") or die "cannot open: $!";
        my @matrix_ACGT=();
        #initial matrix
#	for my $kk (0.. 50)  {
#	        $matrix_ACGT[0][$kk]=0;
#	        $matrix_ACGT[1][$kk]=0;
#	        $matrix_ACGT[2][$kk]=0;
#	        $matrix_ACGT[3][$kk]=0;
#        }
        my @matrix_string=();
        my @matrix_title=();
	my $is_record=0;
        while (<DATA>) {
                if ($is_record ==1) {
                        my @line=split /\t/, $_;
                        #print "@line\n"; 
                        push @matrix_string, $line[0];
                        push @{ $matrix_ACGT[0]}, $line[1];   #no seudo count
                        push @{ $matrix_ACGT[1]}, $line[2]; 
                        push @{ $matrix_ACGT[2]}, $line[3]; 
                        push @{ $matrix_ACGT[3]}, $line[4]; 
                }
                if (/^#/) {
                        $is_record=1;
                } else {
			push @matrix_title, $_;
		}
        }
        return (\@matrix_ACGT, \@matrix_string,\@matrix_title);
        close DATA;
}

sub frequency_to_probability {
    my ($tf_matrix, $tf_maximum_feq)=@_;
    my @predicted_matrix=();
       @predicted_matrix=@$tf_matrix;
 #   my $row=$predicted_matrix[0];
    my $row=$tf_maximum_feq;

     #initial matrix
     # for my $kk (0.. 50)  {
     #           $predicted_matrix[0][$kk]=0;
     #           $predicted_matrix[1][$kk]=0;
     #           $predicted_matrix[2][$kk]=0;
     #           $predicted_matrix[3][$kk]=0;
     #   }

    # print "$input_file - $#predicted_matrix,  \n";
    for my $jj (0.. $#{$row}) {
       #transform to PSAM like foramt
    #   print "$jj \t";
       $predicted_matrix[0][$jj]=($predicted_matrix[0][$jj])/($$tf_maximum_feq[$jj]);
       $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj])/($$tf_maximum_feq[$jj]);
       $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj])/($$tf_maximum_feq[$jj]);
       $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj])/($$tf_maximum_feq[$jj]);
       my $temp_total=$predicted_matrix[0][$jj]+ $predicted_matrix[1][$jj]+ $predicted_matrix[2][$jj]+ $predicted_matrix[3][$jj];
      
       #Convert to probability	
       #This is for yeast only 
       #  $predicted_matrix[0][$jj]=($predicted_matrix[0][$jj]) + 0.31/($temp_total+1);
       #   $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj]) + 0.19/($temp_total+1);
       #  $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj]) + 0.19/($temp_total+1);
       #   $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj]) + 0.31/($temp_total+1);

       $predicted_matrix[0][$jj]=($predicted_matrix[0][$jj]) + 0.25/($temp_total+1);
       $predicted_matrix[1][$jj]=($predicted_matrix[1][$jj]) + 0.25/($temp_total+1);
       $predicted_matrix[2][$jj]=($predicted_matrix[2][$jj]) + 0.25/($temp_total+1);
       $predicted_matrix[3][$jj]=($predicted_matrix[3][$jj]) + 0.25/($temp_total+1);
       $temp_total=$predicted_matrix[0][$jj]+ $predicted_matrix[1][$jj]+ $predicted_matrix[2][$jj]+ $predicted_matrix[3][$jj];
       $predicted_matrix[0][$jj]=$predicted_matrix[0][$jj]/$temp_total;
       $predicted_matrix[1][$jj]=$predicted_matrix[1][$jj]/$temp_total;
       $predicted_matrix[2][$jj]=$predicted_matrix[2][$jj]/$temp_total;
       $predicted_matrix[3][$jj]=$predicted_matrix[3][$jj]/$temp_total;
       #  print "$predicted_matrix[0][$jj],$predicted_matrix[1][$jj], $predicted_matrix[2][$jj], $predicted_matrix[3][$jj]\n";
    }
   return (@predicted_matrix );
}



sub get_exp {                                                           # Get hash of orf -> array of logexpr values by experiment
        my ($file) = @_;                                                # File name of expression data file
        print "\tGetting gene expression data $file ...\n" if defined $file;

        open DATA, "<$file" or die "Could not open $file";              # Open it
        my $head = <DATA>;                                              # Read headers line
        chomp $head;                                                    #
        my @head = split /\t/, $head;                                   # Array of experiment names
#        shift @head;                                                    # Remove GeneID column header
        my $nexps = @head;                                              # Number of columns (=experiments)
        my %E;                                                          # Array for list of gene names
        my $nv = 0;                                                     # Number of expression values possible
        my $undefs = 0;                                                 # Init counter for missing expression values
        my @ids;
        my $dupes = 0;
        while (<DATA>){                                                 # For each line in expression file
        #        next unless $_ =~ /\t-?\d*.?\d+/;                       # Skip line if nothing looks like an expression value
                chomp;                                                  #
                my @line = split /\t/, $_;                              # GeneID + expression values
                my $orf = shift @line;                                  # Get the orfname and leave the array of log values
                $orf=~s/\s//g;           #trim white space
                $orf=~s/'//g;           #trim unregulatory string
                $orf=~s/"//g;
                for my $exper (0..$#line){                              # Loop across columns
                        $nv++;                                          # Count expression values possible
                        if ($line[$exper] !~ /^-?\d*.?\d+([eE][-+]?\d+)?$/){            # If not a valid (signed) real number
                                $line[$exper] = undef;                  # Flag it as undefined
                                $undefs++;                              # Count the N/A lines
                        }
                }
                if (not defined $E{$orf}){
                        $E{$orf} = \@line ;                             # Create hash entry
                        push @ids, $orf;                                # Add to list of valid orfs
                }
                else {
                        $dupes++;
                }
        }
        my $norfs = @ids;
        close DATA;
        print "\t* $norfs total row in $nexps columns (missing $undefs of $nv expression values; $dupes duplicate entries).\n" ; # Report        
        return (\%E, \@ids, \@head);                                    # Return hash of genes->expression values
}
 

