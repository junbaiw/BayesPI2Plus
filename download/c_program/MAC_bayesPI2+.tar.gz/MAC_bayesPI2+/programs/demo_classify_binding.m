close all
clear all
%http://www2.cs.uregina.ca/~dbd/cs831/notes/confusion_matrix/confusion_matrix.html
%cutoff value to expected p-value
P_cutoff=0.09;
%input file name
f1={
'../demo_in/demo_swi4_0.5Kseq_cacgaaaa_500.txt_mlpout_L9_4.mlp_bindingP_0_randomBackground_1000'
%'../demo_out/swi4/demo_in/demo_swi4_0.5Kseq_cacgaaaa_500.txt_mlpout_L9_1.mlp_bindingP_0_randomBackground_1000'
%'../demo_in/demo_ace2_0.5Kseq_gctggt_500.txt_mlpout_L7_4.mlp_bindingP_0_randomBackground_1000'
%'../demo_out/ace2/demo_in/demo_ace2_0.5Kseq_gctggt_500.txt_mlpout_L9_1.mlp_bindingP_0_randomBackground_1000'
}
[out_matrix1, AC(1,:), TP(1,:),FP(1,:),TN(1,:),FN(1,:), Per(1,:),direct_binding,indirect_binding]=confusMatrix_2014(f1,P_cutoff)

real_binding=direct_binding{1};
notreal_binding=indirect_binding{1};

%plot figures
figure(1)
subplot(2,1,1)
[N,bin]=histc(real_binding(:,9),-2:0.5:6);
plot(-2:0.5:6,N,'ro-');
hold on
[oN,obin]=histc(notreal_binding(:,9),-2:0.5:6);
plot(-2:0.5:6,oN,'bo-');
ll=legend('Direct binding','Indirect binding');
xl=xlabel('Log normalized tag density');
yl=ylabel('Number of peaks');
%tl=title(['Direct binding with expected P-value <', num2str(P_cutoff)]);
tl=title('ACE2');
set(xl,'FontSize',15);
set(yl,'FontSize',15);
set(tl,'FontSize',15);
set(gca,'FontSize',12);
set(ll,'FontSize',10);

subplot(2,1,2)
[N,bin]=histc(real_binding(:,3),-2:0.25:3);
semilogy(-2:0.25:3, N+1,'ro-');
hold on
[oN,obin]=histc(notreal_binding(:,3),-2:0.25:3);
semilogy(-2:0.25:3, oN+1,'bo-');
ll=legend('Direct binding','Indirect binding');
%xl=xlabel('Binding affinnity - mean of binding affinity on randomly shuffled sequenecs')
%dbA = differential binding affinity=  binding affinity - mean of binding affinity on randomly shuffled sequences
xl=xlabel('dbA');
yl=ylabel('Number of peaks');
%title(['Direct binding with expected P-value <', num2str(P_cutoff)]);
%tl=title('STAT1')
set(tl,'FontSize',15);
set(xl,'FontSize',15);
set(yl,'FontSize',15);
set(gca,'FontSize',12);
set(ll,'FontSize',10);
set(gcf,'PaperPositionMode','auto')
set(gcf,'Position',[0 0 450 900]);


