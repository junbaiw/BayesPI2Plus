#!/usr/bin/perl -w
use lib "/opt/local/lib/perl5/site_perl/5.12.3/";
use lib "./programs/BioPerl/";

use Bio::SeqIO;

use strict;
use Getopt::Long; 
use Cwd;
use DB_File;


#Randomly shuff DNA sequence N times then use bayesPI_affinity to compute the PSAM binding affinity
#for estimating a significant level of PSAM binding affinity.

#read parameters
use vars map {"\$opt_$_"} qw(normalize motif numP expFile seqFile affinityFile psamFile loops);

GetOptions qw(normalize=s motif=s numP=s expFile=s seqFile=s affinityFile=s psamFile=s loops=s);
print "must specify -seqFile file for input sequences" and die unless defined $opt_seqFile;
print "must specify -affinityFile file for input affinity profiles" and die unless defined $opt_affinityFile;
print "must specify -expFile file for input expression data"  and die unless defined $opt_expFile;
print "must specify -psamFile file for input PSAM matrice" and die unless defined $opt_psamFile;
print "must specify -loops file for the number of permutation tests" and die unless defined $opt_loops;
print "must specify -numP for the number of processors are used in the calculation" and die unless defined $opt_numP;

if (not defined $opt_normalize) {
	$opt_normalize=2;
}
#output file for final results
my $out_file=join "_", ($opt_affinityFile,"randomBackground",$opt_loops) ;
my $data_base="_random_test_database";
#read input affinity file
my ($aff_exp, $aff_genes, $aff_head) = &get_exp($opt_affinityFile);
my %recorded_data=();
my %recorded_affinity_data=();
#%recorded_data = map { $_ => 0 } @$aff_genes;

#read input sequence and count putative motifs
my ($rh_fa) = &get_seq($opt_seqFile);                                     # Get FASTA data
my %motif_counts=();
my $rev_opt_motif;
if (defined $opt_motif) {
	$rev_opt_motif= &reverse_compl($opt_motif);
 	foreach (keys %$rh_fa) {
		my $temp_seq=$$rh_fa{$_};
		$opt_motif=lc($opt_motif);
		$temp_seq=lc($temp_seq);
		my $count1=0;
		while ($temp_seq =~ /$opt_motif/g) { $count1++ }
		my $count2=0;
	#	my $rev_opt_motif= &reverse_compl($opt_motif);
		while ($temp_seq =~ /$rev_opt_motif/g) { $count2++ }
		$motif_counts{$_}=[$count1,$count2, $count1+$count2]; #forward and reverse match counts
		#print "$_, $opt_motif, $count1, $count2, $temp_seq \n";
	}
}

#randomly shuffered sequences
my $outSeq;
my $loops;
my $opt_expFile2;
my $total_loop=$opt_loops;

#number of processors should be divided by number of random selections and it is integer
my $divided_jobs=int $total_loop/$opt_numP;
my @pids=();
my $pid=();
my $job_loops;
my $out_expFile=join "_",($opt_psamFile,"bindingP","0");
my ($out_exp, $out_genes, $out_head) = &get_exp($out_expFile);

#loop in processors
for ($job_loops=1;$job_loops<=$opt_numP;$job_loops++) {
	die  "could not fork" unless defined(my $pid = fork);
	unless ($pid) {
		&random_test($divided_jobs,$job_loops, $rh_fa, $opt_seqFile,$opt_expFile,$opt_psamFile,$data_base,$aff_genes,$aff_exp,$opt_normalize);	
		die "\t Done $job_loops ";
	}
	push @pids, $pid;
	print "processing $pid $job_loops \n";
} 

foreach (@pids) {
	my $temp= waitpid($_,0);
	print "Done with pid $temp \n";
}

#end number of processors

print "Done with splitting jobs \n";
#Computer sum of counts
my $total_counts=int $divided_jobs*$opt_numP;
my %recorded_counts=();
my %recorded_affinity=();
my $str="_affinity";
%recorded_counts = map { $_ => 0 } @$aff_genes;
%recorded_affinity=map { $_ => 0 } @$aff_genes;
for ($job_loops=1;$job_loops<=$opt_numP;$job_loops++) {
	%recorded_data=();
	%recorded_affinity_data=();
	dbmopen(%recorded_data,"$data_base$job_loops",0666) || die "Cannot open records: $!";
	foreach (keys %recorded_data) {
		if (defined $recorded_counts{$_}) {
			$recorded_counts{$_}=$recorded_counts{$_}+$recorded_data{$_};
			#print "$recorded_data{$_} \n";
		}
	}
	dbmclose(%recorded_data);

	dbmopen(%recorded_affinity_data,"$data_base$job_loops$str",0666) || die "Cannot open records: $!";
        foreach (keys %recorded_affinity_data) {
                if (defined $recorded_affinity{$_}) {
                        $recorded_affinity{$_}=$recorded_affinity{$_}+$recorded_affinity_data{$_};
                 }
        }
	dbmclose(%recorded_affinity_data);
}

#Export test results
print "Exporting $out_file \n";
my @out_head=@$out_head;
$out_head=join "\t", (@out_head);
open (DATA,">$out_file") or die "cannot open: $!";
if (defined $opt_motif) {
     print DATA "ID\taffinity\tmeanBackground_affinity\taffinity-meanBackground_affinity\texpected_P-value\t$out_head\tmotif_counts_forward_strand\tmotif_counts_reverse_strand\ttotal_motif_counts\n";
} else {
     print DATA "ID\taffinity\tmeanBackground_affinity\taffinity-meanBackground_affinity\texpcted_P-value\t$out_head\n";
}

foreach (keys %recorded_counts) {
	my $temp_p=();
	my $temp_affinity=();
	my $temp_backgroundAffinity=();
	my $temp_realAffinity=();
	$temp_p=$recorded_counts{$_}/$total_counts;
	$temp_affinity=$recorded_affinity{$_}/$total_counts;
      	my @temp_gene=@{$$aff_exp{$_}};
	$temp_realAffinity=$temp_gene[1];
	$temp_backgroundAffinity=$temp_affinity;

	$temp_affinity=$temp_gene[1]-$temp_affinity; #real affinity - mean of ranodom affinity
	my @temp_motif=();
	my $temp_motifs=();
	if (defined $opt_motif) {
		@temp_motif=@{$motif_counts{$_}};
		$temp_motifs=join "\t", (@temp_motif);
	}
	my $temp_exp=();
	$temp_exp=join "\t", (@{$$aff_exp{$_}});

	if (defined $opt_motif) {
		print DATA "$_\t$temp_realAffinity\t$temp_backgroundAffinity\t$temp_affinity\t$temp_p\t$temp_exp\t$temp_motifs\n";
	} else {
		 print DATA "$_\t$temp_realAffinity\t$temp_backgroundAffinity\t$temp_affinity\t$temp_p\t$temp_exp\n";
	}
}
close DATA;

#remove tempory files
for ($job_loops=1; $job_loops<=$opt_numP; $job_loops++) {
       my @args=qq(rm -f "$data_base$job_loops");
       system(@args)==0 or die "system @args failed: $?" ;
	
       my $str="_affinity";
       @args=qq(rm -f "$data_base$job_loops$str");
       system(@args)==0 or die "system @args failed: $?" ;
}

for ($job_loops=1; $job_loops<=$opt_numP; $job_loops++) {
	my $temp_name=join "_",($opt_psamFile,"bindingP",$job_loops);
 	my @args=qq(rm -f "$temp_name");
	system(@args)==0 or die "system @args failed: $?" ;

	$temp_name=join "_", ($opt_seqFile,"rand",$job_loops);
	@args=qq(rm -f "$temp_name");
	system(@args)==0 or die "system @args failed: $?" ;
}



########################SUBS #########################################
sub random_test {
 my ($divided_jobs, $job_loops,$rh_fa,$opt_seqFile, $opt_expFile,$opt_psamFile,$data_base,$aff_genes,$aff_exp,$opt_normalize)= @_;
 my $loops;
 my %recorded_data=();
 %recorded_data = map { $_ => 0 } @$aff_genes;
 my %recorded_affinity=();
 %recorded_affinity= map {$_ =>0 } @$aff_genes;
 my $rh_exp=();
 my $ra_genes=();
 my $ra_head=();

#loop in divided jobs for random permutations
 for ($loops=1; $loops<=$divided_jobs; $loops++) { 
      #output file name for each randomly permutated sequence data
      $outSeq=join "_", ($opt_seqFile,"rand",$job_loops);
      open (DATA,">$outSeq") or die "cannot open: $!";

      #shuffle seqeunce order and export to tempory random file
      print "\tShuffing sequnece .... $loops \n";
      foreach (keys %$rh_fa) {
           my $seqs=$$rh_fa{$_};
           my @seqs_array=[];
           my $seqs_string=[];
           @seqs_array=split(//,$seqs);    #string to array
           #shuffering each sequence
           &fisher_yates_shuffle(\@seqs_array);
           $seqs_string="@seqs_array";     #array to string
           $seqs_string=~s/(.)\s/$1/seg;   #replace the Extra separating spaces with blank
           print DATA ">$_\n";
                                                                                                                                                                                                              print DATA "$seqs_string\n";
       }
	close DATA;

       #run bayesPI_affinity on shuffed sequence 
       my @args=("./programs/bayesPI_affinity", "-oNum=$job_loops","-normalize=$opt_normalize", "-potential=1", "-dependence=0", "-strand=2", "-exp=$opt_expFile", "-psam=$opt_psamFile","-seq=$outSeq");
       system(@args)==0 or die "system  @args failed: $?";
       
       #read affinity for random sequences
       $rh_exp=();
       $ra_genes=();
       $ra_head=();
       $opt_expFile2=join "_",($opt_psamFile,"bindingP",$job_loops);
       ($rh_exp, $ra_genes, $ra_head) = &get_exp($opt_expFile2);
       #store Y/Z/A results in hash
       #column labls: ID, Y, Z, A, Normalized reads, Raw reads
       my $loop_col=1;
       foreach (@$ra_genes) {
               my @temp=();
               my @aff_temp=();

               if (defined $recorded_data{$_}) {
                  @temp=@{$$rh_exp{$_}};
                  @aff_temp=@{$$aff_exp{$_}};
                  if ($temp[$loop_col]>=$aff_temp[$loop_col]) {
                      $recorded_data{$_}=$recorded_data{$_}+1;
		   }
		$recorded_affinity{$_}=$recorded_affinity{$_}+$temp[$loop_col];
	       }       
        #       print "$_ , @temp, @aff_temp, $recorded_data{$_}, \n";
	}       
   }                                                                                                                                                                                                 #Export data
  my %out_recorded_data=();
  dbmopen(%out_recorded_data, "$data_base$job_loops",0666) || die "Cannot open: $!";
  foreach (keys %recorded_data) {
        $out_recorded_data{$_}=$recorded_data{$_};
  }
 dbmclose(%out_recorded_data);

 my %out_recorded_affinity=();
 my $str="_affinity";
 dbmopen(%out_recorded_affinity, "$data_base$job_loops$str",0666) || die "Cannot open: $!";
 foreach (keys %recorded_affinity) {
        $out_recorded_affinity{$_}=$recorded_affinity{$_};
 }
 dbmclose(%out_recorded_affinity);
} #end sub

sub fisher_yates_shuffle {
    my $array = shift;
    my $i;
    for ($i = @$array; --$i; ) {
        my $j = int rand ($i+1);
        next if $i == $j;
        @$array[$i,$j] = @$array[$j,$i];
    }
}

sub get_seq {                                                                   # Get FASTA data (hash) and Motif dictionary (array)
        print "\tReading sequence data $opt_seqFile ...\n" if defined $opt_seqFile;                 # report progress
        my ($file) = @_;                                                        # Sequence file
        my %fa;                                                                 # Hash for Id->seq
        my $nseqs = 0;                                                          # Record counter
        my $dupes = 0;                                                          # Counter for duplicate IDs
        my $set = Bio::SeqIO->new('-file' => "<$file", '-format' => 'fasta');   # Create new FASTA file object
        while (my $gene = $set->next_seq()){                                    # For each FASTA entry
                $nseqs++;                                                       # Count FASTA file entries
                my $orf = $gene->id();                                          # Get the Gene ID
                $orf=~s/\s//g;           #trim white space
                $orf=~s/'//g;           #trim unregulatory string
                $orf=~s/"//g;
                my $seq = $gene->seq();                                         # Get the sequence
                $seq = "\U$seq";                                                # Force upper case sequence
                if (exists $fa{$orf}){                                          # If this is a duplicate GeneID
                        $dupes++;                                               # Count dupes
                }
                else{
                        $fa{$orf} = $seq;                                       # Build hash of GeneID -> sequence
                }
        }
        print "\t* $nseqs fasta entries (including $dupes duplicates).\n" if defined $opt_seqFile;    # report counts
        return (\%fa);                                                  # Return FASTA data (hash)
}
          

sub get_exp {                                                           # Get hash of orf -> array of logexpr values by experiment
        my ($file) = @_;                                                # File name of expression data file
    	print "\tGetting gene expression data $file ...\n" if defined $file;

	open DATA, "<$file" or die "Could not open $file";              # Open it
        my $head = <DATA>;                                              # Read headers line
        chomp $head;                                                    #
        my @head = split /\t/, $head;                                   # Array of experiment names
        shift @head;                                                    # Remove GeneID column header
        my $nexps = @head;                                              # Number of columns (=experiments)
        my %E;                                                          # Array for list of gene names
        my $nv = 0;                                                     # Number of expression values possible
        my $undefs = 0;                                                 # Init counter for missing expression values
        my @ids;
        my $dupes = 0;
        while (<DATA>){                                                 # For each line in expression file
    #            next unless $_ =~ /\t-?\d*.?\d+/;                       # Skip line if nothing looks like an expression value
                chomp;                                                  #
    		my $temp=$_;
		$temp=~s/\r//g;
		$temp=~s/\n//g;
	        my @line = split /\t/, $temp;                              # GeneID + expression values
                my $orf = shift @line;                                  # Get the orfname and leave the array of log values
                $orf=~s/\s//g;           #trim white space
                $orf=~s/'//g;           #trim unregulatory string
                $orf=~s/"//g;
                for my $exper (0..$#line){                              # Loop across columns
                        $nv++;                                          # Count expression values possible
                        $line[$exper]=~s/\s//g;
			if ($line[$exper] !~ /^-?\d*.?\d+([eE][-+]?\d+)?$/){            # If not a valid (signed) real number
                                $line[$exper] = undef;                  # Flag it as undefined
                                $undefs++;                              # Count the N/A lines
                        }
                }
                if (not defined $E{$orf}){
                        $E{$orf} = \@line ;                             # Create hash entry
                        push @ids, $orf;                                # Add to list of valid orfs
                }
                else {
                        $dupes++;
                }
        }
        my $norfs = @ids;
        close DATA;
        print "\t* $norfs total genes in $nexps experiments (missing $undefs of $nv expression values; $dupes duplicate entries).\n" if defined $opt_expFile ; # Report        
        return (\%E, \@ids, \@head);                                    # Return hash of genes->expression values
}

# reverse complement the motif
sub reverse_compl
{
     my($word) = @_;

     $word = reverse( split("", $word) );
     $word =~ tr /acgt/tgca/ ;
     $word =~ tr /ACGTBDHVMRWSYK/TGCAVHDBKYWSRM/ ;
     return $word;
}

