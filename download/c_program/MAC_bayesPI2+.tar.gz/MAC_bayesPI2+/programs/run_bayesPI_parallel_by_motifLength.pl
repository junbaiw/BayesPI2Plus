#!/usr/bin/perl -w
use lib "/opt/local/lib/perl5/site_perl/5.12.3/";

#use Bio::SeqIO;
use strict;
use Getopt::Long; 
use Cwd;
use DB_File;


# this program splitting the job into N processors for N motif length then run bayesPI in parallel
#
#
#t

#read parameters
use vars map {"\$opt_$_"} qw(flank_sequence max_evidence dependence numP expFile seqFile loops iteration normalization out min_L max_L p_value strand);
GetOptions qw(flank_sequence=s max_evidence=s dependence=s numP=s expFile=s seqFile=s loops=s iteration=s normalization=s out=s min_L=s max_L=s p_value=s strand=s);

print "must specify -seqFile file for input DNA sequence of all peak calls (both weak and strong calls)  " and die unless defined $opt_seqFile;
print "must specify -expFile file for input Tag counts of peak calls " and die unless defined $opt_expFile;
#print "must specify -iteration for input maximum number of iterations in SCG alogrithm (bayesPI parameter) " and die unless defined $opt_iteration;
#print "must specify -loops file for input maximum number of loops for each motif length (bayesPI parameter) " and die unless defined $opt_loops;
#print "must specify -normalization for input the normalization method for input Tag counts (bayesPI parameter) " and die unless defined $opt_normalization;
print "must specify -out for input the location of output data (bayesPI parameter) " and die unless defined $opt_out;
print "must specify -min_L for input the minimum motif length (bayesPI parameter) " and die unless defined $opt_min_L;
print "must specify -max_L for input the maximum motif length (bayesPI parameter) " and die unless defined $opt_max_L;
#print "must specify -p_value for input the p-value cutoff of motif search (bayesPI paramter) " and die unless defined $opt_p_value;
print "must specify -numP for the number of processors used in the calculation" and die unless defined $opt_numP;

#Default paramters for bayesPI
if (not defined $opt_flank_sequence) {
	$opt_flank_sequence=0;
}

if (not defined $opt_p_value) {
	$opt_p_value=0.0001;
}
if (not defined $opt_loops) {
	$opt_loops=3;
}
if (not defined $opt_normalization) {
	$opt_normalization=0;
}
if (not defined $opt_iteration) {
	$opt_iteration=500;
}
if (not defined $opt_strand) {
	$opt_strand=0;
}

if (not defined $opt_dependence) {
	$opt_dependence=0;
}

if (not defined $opt_max_evidence) {
	$opt_max_evidence=3;
}
#randomly split N motif length into N processors genes then run bayesPI in parallel
#number of processors do not need to equal to the number of motif length in bayesPI
#
my $num_of_motif_length=$opt_max_L-$opt_min_L+1;
my $num_of_motifs_in_each_process= int $num_of_motif_length/$opt_numP;
my %num_of_motifs_in_process=();
my $i;
print "min_L=$opt_min_L, max_L=$opt_max_L, numP=$opt_numP, in $num_of_motifs_in_each_process \n";
for ($i=1;$i<=$opt_numP;$i++) {
	my $temp_min=$opt_min_L+$num_of_motifs_in_each_process*($i-1);
	my $temp_max=$temp_min+$num_of_motifs_in_each_process-1;
	if ($i==$opt_numP and $temp_max>$opt_max_L) {$temp_max=$opt_max_L};
	if ($i==$opt_numP and $temp_max<$opt_max_L) {$temp_max=$opt_max_L};
	$num_of_motifs_in_process{$i}=[$temp_min, $temp_max];
	print " @{$num_of_motifs_in_process{$i}} , $temp_min, $temp_max \n";	
}

my @pids=();
my $pid=();
my $job_loops;

#loop in processors
for ($job_loops=1;$job_loops<=$opt_numP;$job_loops++) {
	die  "could not fork" unless defined(my $pid = fork);
	unless ($pid) {
		my $temp_min_L=@{$num_of_motifs_in_process{$job_loops}}[0];
		my $temp_max_L=@{$num_of_motifs_in_process{$job_loops}}[1];
		&run_bayesPI_in_motif_parallel($job_loops, $opt_seqFile,$opt_expFile,$opt_iteration,$opt_loops,$opt_normalization,$opt_dependence,
				    $temp_min_L, $temp_max_L, $opt_p_value,$opt_out,$opt_strand, $opt_max_evidence,$opt_flank_sequence );
		die "\t Done $job_loops ";
	}
	push @pids, $pid;
	print "processing $pid $job_loops \n";
} 

foreach (@pids) {
	my $temp= waitpid($_,0);
	print "Done with pid $temp \n";
}
#end number of processors
print "Done with splitting motifs \n";


########################SUBS #########################################
sub run_bayesPI_in_motif_parallel {
 my($job_loops, $opt_seqFile,$opt_expFile,$opt_iteration,$opt_loops,$opt_normalization,$opt_dependence,
                                    $opt_min_L, $opt_max_L, $opt_p_value,$opt_out,$opt_strand,$opt_max_evidence, $opt_flank_sequence)=@_;
    
   #my $random = int( rand(51)) + 1;
   my $order=length($opt_expFile);
   my $ln=int $order*0.6;
#show 60% of file names
   my $random=substr($opt_expFile,$order-$ln,$ln);

   #run bayesPI on selected motif length 
   #  my @args=("./bayesPI", "-max_loop=$opt_loops","-max_iteration=$opt_iteration","-normalize=$opt_normalization", "-exp=$outExp", "-seq=$opt_seqFile",
   #		"-min_L=$opt_min_L","-max_L=$opt_max_L", "-p_value=$opt_p_value", "-out=$opt_out","\>","log_$job_loops","&");
   my @args=qq( \(time ./programs/bayesPI -flank_sequence="$opt_flank_sequence" -max_evidence="$opt_max_evidence" -dependence="$opt_dependence" -strand="$opt_strand" -max_loop="$opt_loops" -max_iteration="$opt_iteration" -normalize="$opt_normalization" -exp="$opt_expFile" -seq="$opt_seqFile" -min_L="$opt_min_L" -max_L="$opt_max_L" -p_value="$opt_p_value" -out="$opt_out" \) 2> "$opt_out"/log_"$opt_min_L"_"$job_loops"_"$random" );
   system(@args)==0 or die "system  @args failed: $?";
} #end sub


sub export_tag_counts{
        my ($outfile, $column_names_weak, $ids,$strong,$weak)=@_;
        open (DATA, ">$outfile") or die "cannot open: $!";
 	my $new_head= join "\t", ("ID",@$column_names_weak);
	my $new_line=(); 
        print DATA " $new_head\n";
        foreach (@$ids) {
                if (defined $$strong{$_}) {
			$new_line=join "\t", ($_,@{$$strong{$_}});
                        print DATA "$new_line\n";     
                } elsif  (defined $$weak{$_}) { 
			$new_line=join "\t", ($_,@{$$weak{$_}});
                        print DATA "$new_line\n";
                } else { print "not find $_\n";}
        }
        close DATA;
}

sub fisher_yates_shuffle {
    my $array = shift;
    my $i;
    for ($i = @$array; --$i; ) {
        my $j = int rand ($i+1);
        next if $i == $j;
        @$array[$i,$j] = @$array[$j,$i];
    }
}

sub get_seq {                                                                   # Get FASTA data (hash) and Motif dictionary (array)
        print "\tReading sequence data $opt_seqFile ...\n" if defined $opt_seqFile;                 # report progress
        my ($file) = @_;                                                        # Sequence file
        my %fa;                                                                 # Hash for Id->seq
        my $nseqs = 0;                                                          # Record counter
        my $dupes = 0;                                                          # Counter for duplicate IDs
        my $set = Bio::SeqIO->new('-file' => "<$file", '-format' => 'fasta');   # Create new FASTA file object
        while (my $gene = $set->next_seq()){                                    # For each FASTA entry
                $nseqs++;                                                       # Count FASTA file entries
                my $orf = $gene->id();                                          # Get the Gene ID
                $orf=~s/\s//g;           #trim white space
                $orf=~s/'//g;           #trim unregulatory string
                $orf=~s/"//g;
                my $seq = $gene->seq();                                         # Get the sequence
                $seq = "\U$seq";                                                # Force upper case sequence
                if (exists $fa{$orf}){                                          # If this is a duplicate GeneID
                        $dupes++;                                               # Count dupes
                }
                else{
                        $fa{$orf} = $seq;                                       # Build hash of GeneID -> sequence
                }
        }
        print "\t* $nseqs fasta entries (including $dupes duplicates).\n" if defined $opt_seqFile;    # report counts
        return (\%fa);                                                  # Return FASTA data (hash)
}
          

sub get_exp {                                                           # Get hash of orf -> array of logexpr values by experiment
        my ($file) = @_;                                                # File name of expression data file
    	print "\tGetting gene expression data $file ...\n" if defined $file;

	open DATA, "<$file" or die "Could not open $file";              # Open it
        my $head = <DATA>;                                              # Read headers line
        chomp $head;                                                    #
        my @head = split /\t/, $head;                                   # Array of experiment names
        shift @head;                                                    # Remove GeneID column header
        my $nexps = @head;                                              # Number of columns (=experiments)
        my %E;                                                          # Array for list of gene names
        my $nv = 0;                                                     # Number of expression values possible
        my $undefs = 0;                                                 # Init counter for missing expression values
        my @ids;
        my $dupes = 0;
        while (<DATA>){                                                 # For each line in expression file
    #            next unless $_ =~ /\t-?\d*.?\d+/;                       # Skip line if nothing looks like an expression value
                chomp;                                                  #
             	$_=~s/\r//g;
		$_=~s/\n//g;
		my @line = split /\t/, $_;                              # GeneID + expression values
                my $orf = shift @line;                                  # Get the orfname and leave the array of log values
                $orf=~s/\s//g;           #trim white space
                $orf=~s/'//g;           #trim unregulatory string
                $orf=~s/"//g;
                for my $exper (0..$#line){                              # Loop across columns
                        $nv++;                                          # Count expression values possible
                        $line[$exper]=~s/\s//g;
			if ($line[$exper] !~ /^-?\d*.?\d+([eE][-+]?\d+)?$/){            # If not a valid (signed) real number
                                $line[$exper] = undef;                  # Flag it as undefined
                                $undefs++;                              # Count the N/A lines
                        }
                }
                if (not defined $E{$orf}){
                        $E{$orf} = \@line ;                             # Create hash entry
                        push @ids, $orf;                                # Add to list of valid orfs
                }
                else {
                        $dupes++;
                }
        }
        my $norfs = @ids;
        close DATA;
        print "\t* $norfs total genes in $nexps experiments (missing $undefs of $nv expression values; $dupes duplicate entries).\n" if defined $file ; # Report        
        return (\%E, \@ids, \@head);                                    # Return hash of genes->expression values
}
 
