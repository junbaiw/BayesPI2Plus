function norm_data=log_normalize(data);

min_data=min(data);
norm_data=log(data-min_data+1);
