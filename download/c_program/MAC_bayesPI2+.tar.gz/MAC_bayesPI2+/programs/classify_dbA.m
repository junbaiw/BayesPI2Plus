function classify_dbA(f,P_cutoff)
%Input f is file name of N time random shuffle DNA sequence, 
%P_cutoff is cutof value for direct or indirect binding sites


[data,vars,cases]=tblread(f,'\t');
all_data=data; 
P=all_data(:,2);
%P_cutoff=0.09; %cutoff(k)
out_vars=vars; 

disp('Fuzzy nGas classify data ')
dbA=all_data(:,3);
P=all_data(:,4);
%classify two clusters
mean_affinity=all_data(:,2);
x=log_normalize(all_data(:,1))-log_normalize(mean_affinity);
c=2;
y0=abs(rand(c,size(x,2))-0.5)*10e-5;
y0(2,1)=-y0(2,1);
beta=1.5;
epc=1*10^(-4);
N=500;
isplot=0;
epochs=100;
[fuzzy_center, fuzzy_member]=fuzzy_nGas(x,y0,c,beta,epochs);
if fuzzy_center(1)>fuzzy_center(2)
                idx1= find(fuzzy_member(2,:)>fuzzy_member(1,:)   & P'>=0.09 ) ;% fuzzy_member(2,:)>=0.9 );
                idx2=setdiff(1:size(x,1),idx1);
                real_binding=all_data(idx2,:);
                real_cases=cases(idx2,:);
                notreal_binding=all_data(idx1,:);
                notreal_cases=cases(idx1,:);
                out_member1=fuzzy_member(:,idx2);
                out_member2=fuzzy_member(:,idx1);
                real_x=x(idx2);
                notreal_x=x(idx1);
else
                idx1= find(fuzzy_member(1,:)>fuzzy_member(2,:) & P'>=0.09) ; %fuzzy_member(1,:)>=0.9 );
                idx2=setdiff(1:size(x,1),idx1);
                real_binding=all_data(idx2,:);
                real_cases=cases(idx2,:);
                notreal_binding=all_data(idx1,:);
                notreal_cases=cases(idx1,:);
                out_member1=fuzzy_member(:,idx2);
                out_member2=fuzzy_member(:,idx1);
                real_x=x(idx2);
                notreal_x=x(idx1);

end

%export data
varss=cellstr(out_vars);
varss{length(varss)+1}='Fuzzy memebr1';
varss{length(varss)+1}='Fuzzy member2';

out1=[f,'_directBinding']
out2=[f,'_nonDirectBinding']

tblwrite([real_binding,out_member1'],strvcat(varss),real_cases,out1,'\t');
tblwrite([notreal_binding,out_member2'],strvcat(varss),notreal_cases,out2,'\t');

%plot figures
figure(1)
subplot(2,1,1)
[N,bin]=histc(real_binding(:,6),-2:0.5:6);
plot(-2:0.5:6,N,'ro-');
hold on
[oN,obin]=histc(notreal_binding(:,6),-2:0.5:6);
plot(-2:0.5:6,oN,'bo-');
ll=legend('type I (direct)','type II (indirect)');
xl=xlabel('Log normalized tag density');
yl=ylabel('Number of peaks');
set(xl,'FontSize',15);
set(yl,'FontSize',15);
set(gca,'FontSize',12);
set(ll,'FontSize',10);

subplot(2,1,2)
[N,bin]=histc(real_x,-2:0.25:3);
semilogy(-2:0.25:3, N+1,'ro-');
hold on
[oN,obin]=histc(notreal_x,-2:0.25:3);
semilogy(-2:0.25:3, oN+1,'bo-');
ll=legend('type I (direct)','type II (indirect)');
%dbA = differential binding affinity=  binding affinity - mean of binding affinity on randomly shuffled sequences
xl=xlabel('dbA');
yl=ylabel('Number of peaks');
%set(tl,'FontSize',15);
set(xl,'FontSize',15);
set(yl,'FontSize',15);
set(gca,'FontSize',12);
set(ll,'FontSize',10);


